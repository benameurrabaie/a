"""
test_cuda.py -- comprehensive CUDA / PyTorch GPU check.
Run: python test_cuda.py
"""

import sys
import platform
import subprocess

def section(title):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)

# ----------------------------------------------------------------------
# 1. System / driver info
# ----------------------------------------------------------------------
section("1. SYSTEM & DRIVER")

print(f"Python          : {sys.version.split()[0]}")
print(f"Platform        : {platform.platform()}")
print(f"Machine         : {platform.machine()}")

# nvidia-smi is the ground truth for driver + GPU visibility
try:
    out = subprocess.check_output(
        ["nvidia-smi",
         "--query-gpu=name,driver_version,memory.total,memory.free,compute_cap",
         "--format=csv,noheader"],
        stderr=subprocess.STDOUT, text=True, timeout=10)
    print("nvidia-smi      : OK")
    for i, line in enumerate(out.strip().splitlines()):
        print(f"  GPU {i}: {line.strip()}")
except FileNotFoundError:
    print("nvidia-smi      : NOT FOUND  -> no NVIDIA driver installed (or not on PATH)")
except subprocess.CalledProcessError as e:
    print(f"nvidia-smi      : FAILED  -> {e.output.strip()}")
except Exception as e:
    print(f"nvidia-smi      : ERROR  -> {type(e).__name__}: {e}")

# ----------------------------------------------------------------------
# 2. PyTorch build info
# ----------------------------------------------------------------------
section("2. PYTORCH BUILD")

try:
    import torch
except ImportError:
    print("torch is NOT installed.  ->  pip install torch --index-url https://download.pytorch.org/whl/cu121")
    sys.exit(1)

print(f"torch version           : {torch.__version__}")
print(f"torch.version.cuda      : {torch.version.cuda}   (None = CPU-only wheel)")
print(f"torch.backends.cudnn    : {torch.backends.cudnn.version() if torch.backends.cudnn.is_available() else 'N/A'}")
print(f"torch.backends.mkldnn   : {torch.backends.mkldnn.is_available()}")
print(f"compiled with CUDA      : {torch.cuda.is_available() or torch.version.cuda is not None}")

# ----------------------------------------------------------------------
# 3. CUDA availability
# ----------------------------------------------------------------------
section("3. CUDA AVAILABILITY")

cuda_ok = torch.cuda.is_available()
print(f"torch.cuda.is_available(): {cuda_ok}")
print(f"torch.cuda.device_count(): {torch.cuda.device_count()}")
print(f"torch.cuda.current_device(): {torch.cuda.current_device() if cuda_ok else 'N/A'}")

if not cuda_ok:
    print("\n>>> CUDA is NOT available to PyTorch. Common causes:")
    print("    - Installed a CPU-only torch wheel (pip install torch, on Windows/Colab).")
    print("      Fix: pip uninstall -y torch")
    print("           pip install torch --index-url https://download.pytorch.org/whl/cu121")
    print("    - CUDA_VISIBLE_DEVICES is set to an empty/invalid value in your shell.")
    print("    - Driver too old for the CUDA version torch was built against.")
    print("    - Running inside a container without --gpus all.")
    sys.exit(0)

# ----------------------------------------------------------------------
# 4. Per-device properties
# ----------------------------------------------------------------------
section("4. DEVICE PROPERTIES")

for i in range(torch.cuda.device_count()):
    p = torch.cuda.get_device_properties(i)
    free, total = torch.cuda.mem_get_info(i)
    print(f"GPU {i}: {p.name}")
    print(f"    compute capability : {p.major}.{p.minor}")
    print(f"    total memory       : {total / 1024**3:.2f} GB")
    print(f"    free memory        : {free / 1024**3:.2f} GB")
    print(f"    multiprocessors    : {p.multi_processor_count}")
    print(f"    L2 cache           : {p.L2_cache_size / 1024**2:.1f} MB")

# ----------------------------------------------------------------------
# 5. Functional smoke test: matmul on GPU, compare to CPU
# ----------------------------------------------------------------------
section("5. FUNCTIONAL SMOKE TEST (matmul + autograd)")

try:
    torch.manual_seed(0)
    n = 2048
    a_cpu = torch.randn(n, n)
    b_cpu = torch.randn(n, n)
    ref = a_cpu @ b_cpu

    a_gpu = a_cpu.to("cuda")
    b_gpu = b_cpu.to("cuda")
    out_gpu = a_gpu @ b_gpu
    torch.cuda.synchronize()

    max_err = (out_gpu.cpu() - ref).abs().max().item()
    print(f"matmul {n}x{n} max abs error vs CPU: {max_err:.3e}  {'OK' if max_err < 1e-3 else 'FAIL'}")

    # autograd on GPU
    x = torch.randn(64, 64, device="cuda", requires_grad=True)
    y = (x ** 2).sum()
    y.backward()
    print(f"autograd on GPU                     : OK (grad norm={x.grad.norm().item():.4f})")

    # mixed precision
    with torch.autocast(device_type="cuda", dtype=torch.float16):
        _ = a_gpu @ b_gpu
    torch.cuda.synchronize()
    print("autocast float16                    : OK")

except Exception as e:
    print(f"SMOKE TEST FAILED: {type(e).__name__}: {e}")

# ----------------------------------------------------------------------
# 6. Rough GPU timing benchmark vs CPU
# ----------------------------------------------------------------------
section("6. TIMING BENCHMARK (2048x2048 matmul x100)")

import time

def bench(device, dtype=torch.float32, iters=100):
    a = torch.randn(2048, 2048, device=device, dtype=dtype)
    b = torch.randn(2048, 2048, device=device, dtype=dtype)
    # warmup
    for _ in range(5):
        _ = a @ b
    if device == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(iters):
        _ = a @ b
    if device == "cuda":
        torch.cuda.synchronize()
    return (time.perf_counter() - t0) / iters * 1000  # ms

try:
    cpu_ms = bench("cpu")
    gpu_ms = bench("cuda")
    gpu_fp16_ms = bench("cuda", dtype=torch.float16)
    print(f"CPU  fp32 : {cpu_ms:8.2f} ms/iter")
    print(f"GPU  fp32 : {gpu_ms:8.2f} ms/iter   (speedup {cpu_ms/gpu_ms:5.1f}x)")
    print(f"GPU  fp16 : {gpu_fp16_ms:8.2f} ms/iter   (speedup {cpu_ms/gpu_fp16_ms:5.1f}x)")
except Exception as e:
    print(f"BENCHMARK FAILED: {type(e).__name__}: {e}")

# ----------------------------------------------------------------------
# 7. Memory stress (optional -- confirm you can actually allocate VRAM)
# ----------------------------------------------------------------------
section("7. VRAM ALLOCATION TEST")

try:
    free, total = torch.cuda.mem_get_info()
    # try to allocate ~1 GB
    t = torch.empty(int(1e9 // 4), dtype=torch.float32, device="cuda")
    t.fill_(1.0)
    torch.cuda.synchronize()
    print(f"allocated 1.0 GB tensor on GPU       : OK")
    del t
    torch.cuda.empty_cache()
    print(f"cache cleared, free now              : {torch.cuda.mem_get_info()[0]/1024**3:.2f} GB")
except Exception as e:
    print(f"VRAM ALLOCATION FAILED: {type(e).__name__}: {e}")

# ----------------------------------------------------------------------
# Summary
# ----------------------------------------------------------------------
section("SUMMARY")
print(f"CUDA usable          : {cuda_ok}")
print(f"torch.version.cuda   : {torch.version.cuda}")
print(f"device count         : {torch.cuda.device_count()}")
print("\nIf all above looks good, use in your code:")
print('    DEVICE = torch.device("cuda")   # force GPU (crashes if unavailable)')
print('    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # safe fallback')