# ==============================================================================
# DP-GMR -- Full Methodology Implementation (Windows-ready, fully resumable)
# Dataset: TON_IoT network dataset (arnobbhowmik/ton-iot-network-dataset)
#
# RESUME: every stage AND every individual run (method x seed, epsilon x seed...)
# is saved atomically to ./checkpoints. If you stop the script (Ctrl+C, crash,
# power loss) just run it again: finished units are loaded, the rest continue.
# To start from scratch, delete the ./checkpoints folder.
#
# Run on Windows:   py dp_gmr_ton_iot.py
# Kaggle auth: set KAGGLE_USERNAME / KAGGLE_KEY env vars, OR place kaggle.json in
# %USERPROFILE%\.kaggle\, OR let kagglehub prompt you for a login on first run.
# ==============================================================================

import os, sys, gc, json, time, pickle, hashlib, warnings, subprocess, shutil, math, re, glob
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple

# Windows consoles default to cp1252; force UTF-8 so prints never crash.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ------------------------------------------------------------------------
# 0. Install dependencies (only what is missing)
# ------------------------------------------------------------------------
def _ensure_packages():
    needed = {"torch": "torch", "sklearn": "scikit-learn", "scipy": "scipy", "statsmodels": "statsmodels",
              "pandas": "pandas", "numpy": "numpy", "matplotlib": "matplotlib", "seaborn": "seaborn",
              "opacus": "opacus", "xgboost": "xgboost", "psutil": "psutil", "kagglehub": "kagglehub[pandas-datasets]"}
    import importlib.util
    missing = [pkg for mod, pkg in needed.items() if importlib.util.find_spec(mod) is None]
    if missing:
        print(f"[setup] installing: {missing}")
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", *missing], check=True)
_ensure_packages()

import numpy as np
import pandas as pd
import psutil
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager
import matplotlib.figure
from scipy import stats
from statsmodels.stats.multitest import multipletests
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

try:
    from opacus.accountants import RDPAccountant as _OpacusRDPAccountant
    from opacus.accountants.utils import get_noise_multiplier as _opacus_get_noise_multiplier
    _OPACUS_AVAILABLE = True
except Exception:
    _OPACUS_AVAILABLE = False
    warnings.warn("opacus unavailable -- falling back to closed-form epsilon approximation.")

warnings.filterwarnings("ignore", message=".*Optimal order is the largest alpha.*")

# ==============================================================================
# 1. GLOBAL CONFIG
# ==============================================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[device] using {DEVICE}")

BASE_DIR = os.path.abspath(os.path.dirname(__file__)) if "__file__" in globals() else os.path.abspath(".")
RESULTS_DIR = os.path.join(BASE_DIR, "results")
RAW_DIR = os.path.join(RESULTS_DIR, "raw")
TAB_DIR = os.path.join(RESULTS_DIR, "tables")
FIG_DIR = os.path.join(RESULTS_DIR, "figures")
CHECKPOINT_DIR = os.path.join(BASE_DIR, "checkpoints")
UNIT_DIR = os.path.join(CHECKPOINT_DIR, "units")          # fine-grained (per-run) checkpoints
DATA_DIR = os.path.join(BASE_DIR, "data")
for d in (RESULTS_DIR, RAW_DIR, TAB_DIR, FIG_DIR, CHECKPOINT_DIR, UNIT_DIR, DATA_DIR):
    os.makedirs(d, exist_ok=True)

DATASET_NAME = "TON_IoT"
TON_HANDLE = "arnobbhowmik/ton-iot-network-dataset"
TON_FILE_CANDIDATES = ["train_test_network.csv", "Train_Test_Network.csv", "train_test_network.CSV"]

QUICK_TEST = False                 # set True to shrink epochs/seeds for a smoke test

EPOCHS_PER_DOMAIN = 8 if QUICK_TEST else 150
GEN_EPOCHS = 20 if QUICK_TEST else 100
DIFFUSION_T = 20 if QUICK_TEST else 100
LR = 5e-3
GEN_LR = 5e-3
REPLAY_CAP_M = 500 if QUICK_TEST else 2000
GRAD_CLIP_MAX_NORM = 5.0
RANDOM_STATE = 42

SEEDS_MAIN = list(range(2))
SEEDS_ABLATION = list(range(2))
SEEDS_PRIVACY = list(range(2))

METHOD_ORDER = ["FineTune", "EWC", "SI", "LWF", "ER",
                "GMR-VAE", "GMR-GAN", "GMR-Diffusion",
                "GMR-VAE-ZT", "GMR-GAN-ZT", "GMR-Diffusion-ZT"]
GENERATIVE_LIST = ["GMR-VAE", "GMR-GAN", "GMR-Diffusion",
                   "GMR-VAE-ZT", "GMR-GAN-ZT", "GMR-Diffusion-ZT"]   # ordered (stable for resume)
GENERATIVE_METHODS = set(GENERATIVE_LIST)
ZT_PAIRS = [("GMR-VAE", "GMR-VAE-ZT"), ("GMR-GAN", "GMR-GAN-ZT"), ("GMR-Diffusion", "GMR-Diffusion-ZT")]
PROPOSED_METHOD = "GMR-GAN"

DP_TARGET_EPSILONS = [1, 3, 8]
DP_DELTA = 1e-5
DP_CLIP_NORM = 1.0
DP_SAMPLE_RATE = 0.5

ZT_TRUST_THRESHOLD = 0.5
ZT_OVERSAMPLE_FACTOR = 3
ZT_HOLDOUT_FRAC = 0.2
ZT_VERIFIER_DP_BUDGET_FRACTION = 0.2
ZT_SUFFIX = "-ZT"

# ------------------------------------------------------------------------
# Plotting style
# ------------------------------------------------------------------------
PREFERRED_FONTS = ["Helvetica Neue", "Arial", "Inter", "Nimbus Sans", "DejaVu Sans"]
_available_fonts = {f.name for f in matplotlib.font_manager.fontManager.ttflist}
FONT = next((f for f in PREFERRED_FONTS if f in _available_fonts), "DejaVu Sans")
BG, PANEL_BG, GRID_COLOR, TEXT_COLOR, SUBTEXT_COLOR = "#FFFFFF", "#FFFFFF", "#DDDDDD", "#1A1A1A", "#5C5C5C"
PALETTE = {
    "ER": "#5C5C5C", "GMR-VAE": "#0072B2", "GMR-GAN": "#009E73", "GMR-Diffusion": "#D55E00",
    "EWC": "#CC79A7", "SI": "#E69F00", "LWF": "#56B4E9", "FineTune": "#A6A6A6",
    "DP-ER": "#8C8C8C", "DP-GMR": "#0072B2", "NonDP-ER": "#5C5C5C", "control": "#B0B0B0", "IG": "#CC79A7",
    "GMR-VAE-ZT": "#5AA9D6", "GMR-GAN-ZT": "#4FCDA5", "GMR-Diffusion-ZT": "#F0A868",
    "DP-GMR-ZT": "#4FCDA5", "poisoned": "#B00020",
}

def apply_plot_style():
    matplotlib.rcParams.update({
        "font.family": FONT, "font.size": 8, "text.color": TEXT_COLOR,
        "axes.edgecolor": "#4D4D4D", "axes.linewidth": 0.7, "axes.labelcolor": TEXT_COLOR,
        "axes.labelsize": 8, "axes.titlesize": 9, "axes.titleweight": "bold",
        "axes.facecolor": PANEL_BG, "figure.facecolor": BG, "savefig.facecolor": BG,
        "xtick.color": SUBTEXT_COLOR, "ytick.color": SUBTEXT_COLOR,
        "xtick.labelsize": 7, "ytick.labelsize": 7,
        "grid.color": GRID_COLOR, "grid.linewidth": 0.5, "axes.grid": True, "axes.axisbelow": True,
        "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "legend.fontsize": 6.5,
        "figure.dpi": 150, "savefig.dpi": 300, "pdf.fonttype": 42, "ps.fonttype": 42,
    })

def style_axes(ax):
    ax.set_facecolor(PANEL_BG)
    ax.grid(True, axis="y", linestyle="-", linewidth=0.5, alpha=0.7, color=GRID_COLOR)
    ax.grid(False, axis="x")
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    for spine in ("left", "bottom"):
        ax.spines[spine].set_color("#4D4D4D")
        ax.spines[spine].set_linewidth(0.7)
    ax.tick_params(length=2.5, width=0.6, color="#4D4D4D")
    return ax

def panel_letter(ax, letter, caption=""):
    ax.set_title(f"({letter})  {caption}" if caption else f"({letter})", loc="left",
                 fontsize=6.3, fontweight="bold", pad=3)

def legend_above(target, ncol=None, fontsize=6.5, handles=None, labels=None):
    is_figure = isinstance(target, matplotlib.figure.Figure)
    if handles is None or labels is None:
        if is_figure:
            return
        handles, labels = target.get_legend_handles_labels()
    if not handles:
        return
    if ncol is None:
        ncol = len(labels)
    if is_figure:
        target.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 1.06),
                      ncol=ncol, fontsize=fontsize, frameon=False, handlelength=1.3, columnspacing=0.9)
    else:
        target.legend(handles, labels, loc="lower center", bbox_to_anchor=(0.5, 1.05),
                      ncol=ncol, fontsize=fontsize, frameon=False, handlelength=1.3,
                      columnspacing=0.9, borderaxespad=0.1)

def log_memory(tag: str = ""):
    try:
        mb = psutil.Process(os.getpid()).memory_info().rss / (1024 ** 2)
        print(f"    [mem] RSS{(' (' + tag + ')') if tag else ''}: {mb:,.0f} MB")
    except Exception:
        pass

def _atomic_pickle(obj, path: str):
    """Write to a temp file, fsync, then os.replace -> never leaves a half-written checkpoint."""
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)

def save_raw(obj, name: str):
    path = os.path.join(RAW_DIR, f"{name}.pkl")
    _atomic_pickle(obj, path)
    print(f"  [raw] saved {path}")

def save_table(df: pd.DataFrame, name: str):
    path = os.path.join(TAB_DIR, f"{name}.csv")
    df.to_csv(path, index=False)
    print(f"  [table] saved {path}")

def save_figure(fig, name: str, caption: str):
    fig.savefig(os.path.join(FIG_DIR, f"{name}.png"), dpi=300, bbox_inches="tight", facecolor=BG)
    fig.savefig(os.path.join(FIG_DIR, f"{name}.pdf"), bbox_inches="tight", facecolor=BG)
    with open(os.path.join(FIG_DIR, f"{name}_caption.txt"), "w", encoding="utf-8") as f:
        f.write(caption.strip() + "\n")
    plt.close(fig)
    print(f"  [figure] saved {name}.png/.pdf + caption")

# ==============================================================================
# 1.5 CHECKPOINT INFRASTRUCTURE (stage-level + unit-level, atomic)
# ==============================================================================
def checkpoint_marker_path(stage_id: str) -> str:
    return os.path.join(CHECKPOINT_DIR, f"{stage_id}.pkl")

def checkpoint_done(stage_id: str) -> bool:
    p = checkpoint_marker_path(stage_id)
    if not os.path.exists(p):
        return False
    try:                                  # verify it is readable; otherwise redo the stage
        with open(p, "rb") as f:
            pickle.load(f)
        return True
    except Exception:
        print(f"  [checkpoint] '{stage_id}' is corrupted -> will recompute")
        return False

def checkpoint_load(stage_id: str):
    with open(checkpoint_marker_path(stage_id), "rb") as f:
        payload = pickle.load(f)
    print(f"  [checkpoint] loaded '{stage_id}' -- skipping recomputation")
    return payload

def checkpoint_save(stage_id: str, payload):
    _atomic_pickle(payload, checkpoint_marker_path(stage_id))
    print(f"  [checkpoint] saved '{stage_id}'")

def _safe_key(key: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.\-]+", "_", key)

def cached_unit(key: str, fn):
    """Run fn() once; persist its (picklable) result. On re-run, load instead of recompute."""
    path = os.path.join(UNIT_DIR, _safe_key(key) + ".pkl")
    if os.path.exists(path):
        try:
            with open(path, "rb") as f:
                out = pickle.load(f)
            print(f"    [resume] unit '{key}' loaded from disk")
            return out
        except Exception:
            print(f"    [resume] unit '{key}' corrupted -> recomputing")
    out = fn()
    _atomic_pickle(out, path)
    return out

print("=" * 78)
print(f"Checkpoint dir: {CHECKPOINT_DIR}\nResults dir:    {RESULTS_DIR}")
print("=" * 78)

# ==============================================================================
# 2. DATA -- TON_IoT network dataset loader
# ==============================================================================
@dataclass
class TaskData:
    x_train: torch.Tensor
    y_train: torch.Tensor
    x_test: torch.Tensor
    y_test: torch.Tensor
    name: str
    flow_keys_train: List[str] = field(default_factory=list)
    n_features: int = field(init=False)
    def __post_init__(self):
        self.n_features = self.x_train.shape[1]

def _task_to_cpu(t):
    return TaskData(t.x_train.detach().cpu(), t.y_train.detach().cpu(), t.x_test.detach().cpu(),
                    t.y_test.detach().cpu(), t.name, t.flow_keys_train)

def _task_to_device(t, device):
    return TaskData(t.x_train.to(device), t.y_train.to(device), t.x_test.to(device),
                    t.y_test.to(device), t.name, t.flow_keys_train)

def tasks_to_cpu(tasks): return [_task_to_cpu(t) for t in tasks]
def tasks_to_device(tasks, device): return [_task_to_device(t, device) for t in tasks]

def _flow_key(vec: np.ndarray) -> str:
    coarse = np.round(vec[:4] * 3).astype(int)
    return hashlib.sha256(coarse.tobytes()).hexdigest()[:16]

CLIP_ABS_VALUE = 1e9
Z_SCORE_CLIP = 8.0

def _load_ton_dataframe() -> pd.DataFrame:
    """Load TON_IoT via kagglehub.load_dataset(KaggleDatasetAdapter.PANDAS, ...).
    Falls back to dataset_download + largest CSV that has a 'type' column."""
    import kagglehub
    from kagglehub import KaggleDatasetAdapter

    def _try_load():
        for fp in TON_FILE_CANDIDATES:
            try:
                df = kagglehub.load_dataset(KaggleDatasetAdapter.PANDAS, TON_HANDLE, fp)
                if "type" in df.columns:
                    print(f"  loaded '{fp}' via kagglehub.load_dataset: {df.shape}")
                    return df
            except Exception as e:
                print(f"  load_dataset('{fp}') failed: {type(e).__name__}: {str(e)[:120]}")
        # fallback: download the whole dataset and look for the right CSV
        path = kagglehub.dataset_download(TON_HANDLE)
        best, best_size = None, -1
        for p in glob.glob(os.path.join(path, "**", "*.csv"), recursive=True):
            try:
                cols = pd.read_csv(p, nrows=0).columns
            except Exception:
                continue
            if "type" in cols and os.path.getsize(p) > best_size:
                best, best_size = p, os.path.getsize(p)
        if best is None:
            raise FileNotFoundError(f"No CSV with a 'type' column found under {path}")
        print(f"  loaded fallback CSV: {best}")
        return pd.read_csv(best, low_memory=False)

    try:
        return _try_load()
    except Exception as e:
        print(f"  first attempt failed ({type(e).__name__}); trying interactive Kaggle login...")
        kagglehub.login()
        return _try_load()

def _build_feature_matrix(df: pd.DataFrame) -> Tuple[np.ndarray, List[str]]:
    """Numeric columns kept (signed-log for heavy tails); low-cardinality categorical columns
    (proto, service, conn_state, dns_*, ssl_*, http_method...) are ordinal-encoded; IPs, timestamps
    and high-cardinality strings (URIs, user agents, subjects) are dropped."""
    drop = {"ts", "src_ip", "dst_ip", "label", "type"}
    cols, mats = [], []
    for c in df.columns:
        if c in drop:
            continue
        s = df[c]
        num = pd.to_numeric(s, errors="coerce")
        if num.notna().mean() > 0.9:
            v = num.fillna(0.0).to_numpy(dtype=np.float64)
            v = np.nan_to_num(v, nan=0.0, posinf=0.0, neginf=0.0)
            v = np.clip(v, -CLIP_ABS_VALUE, CLIP_ABS_VALUE)
            if np.abs(v).max() > 1e3:
                v = np.sign(v) * np.log1p(np.abs(v))
        else:
            s = s.astype(str)
            if s.nunique() > 50:
                continue
            v = pd.factorize(s, sort=True)[0].astype(np.float64)
        mats.append(v.astype(np.float32)); cols.append(c)
    X = np.stack(mats, axis=1)
    keep = X.std(axis=0) > 1e-9                       # drop constant columns
    return X[:, keep], [c for c, k in zip(cols, keep) if k]

def load_ton_iot(n_train_per_class: int, n_test_per_class: int, device=DEVICE) -> List[TaskData]:
    df = _load_ton_dataframe()
    if "type" not in df.columns:
        raise RuntimeError("TON_IoT dataframe has no 'type' column (attack family).")
    rng = np.random.RandomState(RANDOM_STATE)
    types = df["type"].astype(str).str.strip().str.lower().to_numpy()
    X, feat_names = _build_feature_matrix(df)
    print(f"  feature matrix: {X.shape}  ({len(feat_names)} features)")
    print("  class counts:", dict(pd.Series(types).value_counts()))
    del df; gc.collect()

    cap = n_train_per_class + n_test_per_class

    def split_class(mask):
        idx = np.where(mask)[0]
        idx = rng.permutation(idx)[:cap]
        n_te = min(n_test_per_class, max(1, int(0.3 * len(idx))))
        return X[idx[n_te:]], X[idx[:n_te]]          # train, test

    normal_tr, normal_te = split_class(types == "normal")
    if len(normal_tr) == 0:
        raise RuntimeError("No 'normal' samples found.")
    scaler = StandardScaler().fit(normal_tr)

    tasks = []
    for fam in sorted(set(types) - {"normal"}):
        a_tr, a_te = split_class(types == fam)
        if len(a_tr) < 20 or len(a_te) < 5:
            print(f"  skipping family '{fam}' (too few samples: {len(a_tr)}/{len(a_te)})")
            continue
        def prep(xa, xn):
            x = np.clip(scaler.transform(np.concatenate([xa, xn])), -Z_SCORE_CLIP, Z_SCORE_CLIP).astype(np.float32)
            y = np.concatenate([np.ones(len(xa)), np.zeros(len(xn))]).astype(np.int64)
            return x, y
        x_tr, y_tr = prep(a_tr, normal_tr)
        x_te, y_te = prep(a_te, normal_te)
        p_tr, p_te = rng.permutation(len(y_tr)), rng.permutation(len(y_te))
        tasks.append(TaskData(
            x_train=torch.tensor(x_tr[p_tr]).to(device), y_train=torch.tensor(y_tr[p_tr]).to(device),
            x_test=torch.tensor(x_te[p_te]).to(device), y_test=torch.tensor(y_te[p_te]).to(device),
            name=f"Task_{fam.capitalize()}", flow_keys_train=[_flow_key(r) for r in x_tr[p_tr]]))
    print(f"  Loaded {len(tasks)} attack-family tasks: {[t.name for t in tasks]}")
    return tasks

print("=" * 78); print("Loading dataset: TON_IoT network dataset"); print("=" * 78)
_STAGE_ID = "00_dataset"
if checkpoint_done(_STAGE_ID):
    _ckpt = checkpoint_load(_STAGE_ID)
    real_tasks = tasks_to_device(_ckpt["real_tasks_cpu"], DEVICE)
else:
    real_tasks = load_ton_iot(1000, 100, device=DEVICE)
    checkpoint_save(_STAGE_ID, {"real_tasks_cpu": tasks_to_cpu(real_tasks)})

K_REAL = len(real_tasks)
D_REAL = real_tasks[0].n_features
DATASETS = {DATASET_NAME: real_tasks}
K_DOMAINS = K_REAL
print(f"{DATASET_NAME}: {K_REAL} tasks, feature dim={D_REAL}")

# ==============================================================================
# 3. MODELS
# ==============================================================================
class AttentionTabularClassifier(nn.Module):
    def __init__(self, n_features: int, hidden: int = 24, n_heads: int = 2, n_classes: int = 2):
        super().__init__()
        self.n_features, self.hidden, self.n_classes = n_features, hidden, n_classes
        self.token_base = nn.Parameter(torch.randn(n_features, hidden) * 0.1)
        self.value_proj = nn.Linear(1, hidden)
        self.attn = nn.MultiheadAttention(hidden, n_heads, batch_first=True)
        self.norm1 = nn.LayerNorm(hidden)
        self.ffn = nn.Sequential(nn.Linear(hidden, hidden * 2), nn.ReLU(), nn.Linear(hidden * 2, hidden))
        self.norm2 = nn.LayerNorm(hidden)
        self.cls_head = nn.Linear(hidden, n_classes)
    def tokenize(self, x):
        return self.token_base.unsqueeze(0) + self.value_proj(x.unsqueeze(-1))
    def encode_tokens(self, tok):
        attn_out, attn_w = self.attn(tok, tok, tok, need_weights=True, average_attn_weights=True)
        h = self.norm1(tok + attn_out)
        z = self.norm2(h + self.ffn(h))
        return z.mean(dim=1), attn_w
    def forward(self, x, return_attn: bool = False):
        pooled, attn_w = self.encode_tokens(self.tokenize(x))
        logits = self.cls_head(pooled)
        return (logits, attn_w) if return_attn else logits
    def named_important_parameters(self):
        return [(n, p) for n, p in self.named_parameters() if p.requires_grad]

class MLPClassifier(nn.Module):
    def __init__(self, n_features: int, hidden: int, n_classes: int = 2):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_features, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU())
        self.head = nn.Linear(hidden, n_classes)
    def forward(self, x):
        return self.head(self.net(x))
    def named_important_parameters(self):
        return [(n, p) for n, p in self.named_parameters() if p.requires_grad]

class VAEGenerator(nn.Module):
    def __init__(self, n_features, n_classes=2, latent_dim=8, hidden=32):
        super().__init__()
        self.n_features, self.n_classes, self.latent_dim = n_features, n_classes, latent_dim
        self.enc = nn.Sequential(nn.Linear(n_features + n_classes, hidden), nn.ReLU())
        self.mu = nn.Linear(hidden, latent_dim)
        self.logvar = nn.Linear(hidden, latent_dim)
        self.dec = nn.Sequential(nn.Linear(latent_dim + n_classes, hidden), nn.ReLU(), nn.Linear(hidden, n_features))
    def _onehot(self, y): return F.one_hot(y, num_classes=self.n_classes).float()
    def encode(self, x, y):
        h = self.enc(torch.cat([x, self._onehot(y)], dim=1))
        return self.mu(h), self.logvar(h)
    def reparameterize(self, mu, logvar): return mu + torch.randn_like(mu) * torch.exp(0.5 * logvar)
    def decode(self, z, y): return self.dec(torch.cat([z, self._onehot(y)], dim=1))
    def forward(self, x, y):
        mu, logvar = self.encode(x, y)
        return self.decode(self.reparameterize(mu, logvar), y), mu, logvar
    def loss(self, x, y):
        x_hat, mu, logvar = self.forward(x, y)
        recon = F.mse_loss(x_hat, x, reduction="mean")
        kld = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())
        return recon + 0.1 * kld
    @torch.no_grad()
    def sample(self, y):
        return self.decode(torch.randn(y.shape[0], self.latent_dim, device=y.device), y)

class ConditionalGANGenerator(nn.Module):
    def __init__(self, n_features, n_classes=2, latent_dim=8, hidden=32):
        super().__init__()
        self.n_classes, self.latent_dim = n_classes, latent_dim
        self.net = nn.Sequential(nn.Linear(latent_dim + n_classes, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, n_features))
    def forward(self, z, y): return self.net(torch.cat([z, F.one_hot(y, self.n_classes).float()], dim=1))
    @torch.no_grad()
    def sample(self, y):
        return self.forward(torch.randn(y.shape[0], self.latent_dim, device=y.device), y)

class ConditionalGANDiscriminator(nn.Module):
    def __init__(self, n_features, n_classes=2, hidden=32):
        super().__init__()
        self.n_classes = n_classes
        self.net = nn.Sequential(nn.Linear(n_features + n_classes, hidden), nn.LeakyReLU(0.2),
                                 nn.Linear(hidden, hidden), nn.LeakyReLU(0.2), nn.Linear(hidden, 1))
    def forward(self, x, y): return self.net(torch.cat([x, F.one_hot(y, self.n_classes).float()], dim=1))

class ConditionalDenoiser(nn.Module):
    def __init__(self, n_features, n_classes=2, hidden=32, time_embed_dim=8):
        super().__init__()
        self.n_classes = n_classes
        self.time_embed = nn.Sequential(nn.Linear(1, time_embed_dim), nn.ReLU())
        self.net = nn.Sequential(nn.Linear(n_features + n_classes + time_embed_dim, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, n_features))
    def forward(self, x_t, t, y):
        oh = F.one_hot(y, self.n_classes).float()
        temb = self.time_embed(t.float().unsqueeze(-1))
        return self.net(torch.cat([x_t, oh, temb], dim=1))

class DiffusionGenerator(nn.Module):
    def __init__(self, n_features, n_classes=2, hidden=32, T=DIFFUSION_T):
        super().__init__()
        self.n_features, self.T = n_features, T
        self.denoiser = ConditionalDenoiser(n_features, n_classes, hidden)
        betas = torch.linspace(1e-4, 0.02, T)
        alphas = 1.0 - betas
        self.register_buffer("betas", betas)
        self.register_buffer("alphas", alphas)
        self.register_buffer("alphas_cumprod", torch.cumprod(alphas, dim=0))
    def q_sample(self, x0, t, noise=None):
        if noise is None: noise = torch.randn_like(x0)
        ac = self.alphas_cumprod[t].unsqueeze(-1)
        return torch.sqrt(ac) * x0 + torch.sqrt(1 - ac) * noise, noise
    def loss(self, x0, y):
        t = torch.randint(0, self.T, (x0.shape[0],), dtype=torch.long, device=x0.device)
        x_t, noise = self.q_sample(x0, t)
        return F.mse_loss(self.denoiser(x_t, t, y), noise)
    @torch.no_grad()
    def sample(self, y):
        x = torch.randn(y.shape[0], self.n_features, device=y.device)
        for t_ in reversed(range(self.T)):
            t = torch.full((y.shape[0],), t_, dtype=torch.long, device=y.device)
            eps_pred = self.denoiser(x, t, y)
            alpha, alpha_cp, beta = self.alphas[t_], self.alphas_cumprod[t_], self.betas[t_]
            mean = (1.0 / torch.sqrt(alpha)) * (x - (beta / torch.sqrt(1 - alpha_cp)) * eps_pred)
            x = mean + torch.sqrt(beta) * torch.randn_like(x) if t_ > 0 else mean
        return x

def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())

def match_mlp_hidden_size(target_params: int, n_features: int, tol: float = 0.05) -> int:
    best_h, best_gap = None, float("inf")
    for h in range(4, 512):
        gap = abs(count_params(MLPClassifier(n_features, h)) - target_params) / target_params
        if gap < best_gap:
            best_gap, best_h = gap, h
        if gap <= tol:
            return h
    return best_h

def _model_state_for_checkpoint(model: nn.Module) -> dict:
    return dict(cls=type(model).__name__, n_features=model.n_features,
                state_dict={k: v.detach().cpu() for k, v in model.state_dict().items()})

def _model_from_checkpoint(state: dict, device=DEVICE) -> nn.Module:
    m = AttentionTabularClassifier(state["n_features"]).to(device)
    m.load_state_dict({k: v.to(device) for k, v in state["state_dict"].items()})
    m.eval()
    return m

# ==============================================================================
# 4. DP-SGD + RENYI-DP ACCOUNTING
# ==============================================================================
def poisson_subsample_indices(n: int, sample_rate: float, rng: np.random.RandomState = None):
    rng = rng or np.random
    idx = np.nonzero(rng.random_sample(n) < sample_rate)[0]
    return idx if len(idx) else np.array([rng.randint(0, n)])

def clip_and_noise(grads, params, clip_norm: float, noise_multiplier: float):
    batch_size = max(len(grads), 1)
    summed = [torch.zeros_like(p) for p in params]
    for sample_grad in grads:
        total_norm = math.sqrt(sum(g.pow(2).sum().item() for g in sample_grad))
        clip_coef = min(1.0, clip_norm / (total_norm + 1e-6))
        for j, g in enumerate(sample_grad):
            summed[j] += g * clip_coef
    return [(s + torch.randn_like(s) * noise_multiplier * clip_norm) / batch_size for s in summed]

class RDPPrivacyAccountant:
    def __init__(self):
        self._steps = 0
        self._accountant = _OpacusRDPAccountant() if _OPACUS_AVAILABLE else None
        self._noise_multiplier, self._sample_rate = None, None
    def step(self, noise_multiplier: float, sample_rate: float):
        self._steps += 1
        if _OPACUS_AVAILABLE:
            self._accountant.step(noise_multiplier=noise_multiplier, sample_rate=sample_rate)
        else:
            self._noise_multiplier, self._sample_rate = noise_multiplier, sample_rate
    def get_epsilon(self, delta: float = DP_DELTA) -> float:
        if self._steps == 0:
            return float("inf")
        if _OPACUS_AVAILABLE:
            return float(self._accountant.get_epsilon(delta=delta))
        return self._sample_rate * math.sqrt(2 * self._steps * math.log(1 / delta)) / self._noise_multiplier
    @property
    def steps_taken(self): return self._steps

def calibrate_noise_multiplier(target_epsilon: float, sample_rate: float, steps: int, delta: float = DP_DELTA) -> float:
    if _OPACUS_AVAILABLE:
        return float(_opacus_get_noise_multiplier(target_epsilon=target_epsilon, target_delta=delta,
                                                  sample_rate=sample_rate, steps=steps, accountant="rdp"))
    if target_epsilon <= 0:
        return float("inf")
    return sample_rate * math.sqrt(2 * steps * math.log(1 / delta)) / target_epsilon

def dp_train_generator_loss_model(model, x_train, y_train, epochs, lr, clip_norm,
                                  noise_multiplier, sample_rate, accountant):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    n = x_train.shape[0]
    for _ in range(epochs):
        idx = poisson_subsample_indices(n, sample_rate)
        x_sub, y_sub = x_train[idx], y_train[idx]
        params = [p for p in model.parameters() if p.requires_grad]
        grads_list = []
        for i in range(x_sub.shape[0]):
            model.zero_grad(set_to_none=True)
            loss_i = model.loss(x_sub[i:i + 1], y_sub[i:i + 1])
            g = torch.autograd.grad(loss_i, params, retain_graph=False)
            grads_list.append([gi.detach().clone() for gi in g])
        noised = clip_and_noise(grads_list, params, clip_norm, noise_multiplier)
        opt.zero_grad(set_to_none=True)
        for p, g in zip(params, noised):
            p.grad = g
        opt.step()
        accountant.step(noise_multiplier=noise_multiplier, sample_rate=sample_rate)

def dp_sgd_classifier_step(model, optimizer, x_batch, y_batch, clip_norm, noise_multiplier,
                           sample_rate, accountant, rng):
    n = x_batch.shape[0]
    idx = poisson_subsample_indices(n, sample_rate, rng)
    x_sub, y_sub = x_batch[idx], y_batch[idx]
    params = [p for p in model.parameters() if p.requires_grad]
    grads_list = []
    for i in range(x_sub.shape[0]):
        model.zero_grad(set_to_none=True)
        loss_i = F.cross_entropy(model(x_sub[i:i + 1]), y_sub[i:i + 1])
        g = torch.autograd.grad(loss_i, params, retain_graph=False)
        grads_list.append([gi.detach().clone() for gi in g])
    noised = clip_and_noise(grads_list, params, clip_norm, noise_multiplier)
    optimizer.zero_grad(set_to_none=True)
    for p, g in zip(params, noised):
        p.grad = g
    optimizer.step()
    accountant.step(noise_multiplier=noise_multiplier, sample_rate=sample_rate)

# ==============================================================================
# 5. CONTINUAL-LEARNING BASELINES (EWC, SI, LWF)
# ==============================================================================
class EWC:
    def __init__(self, lam=500.0):
        self.lam, self.fisher, self.opt_params = lam, {}, {}
    def before_task(self, model): pass
    def penalty(self, model):
        if not self.fisher:
            return torch.tensor(0.0, device=DEVICE)
        loss = 0.0
        for n, p in model.named_important_parameters():
            if n in self.fisher:
                loss = loss + (self.fisher[n] * (p - self.opt_params[n]).pow(2)).sum()
        return self.lam * loss
    def after_task(self, model, x_train, y_train):
        model.zero_grad(set_to_none=True)
        fisher_new = {n: torch.zeros_like(p) for n, p in model.named_important_parameters()}
        n_samples = x_train.shape[0]
        for i in range(n_samples):
            model.zero_grad(set_to_none=True)
            logp = F.log_softmax(model(x_train[i:i + 1]), dim=1)
            label = torch.multinomial(logp.exp(), 1).squeeze(1)
            F.nll_loss(logp, label).backward()
            for n, p in model.named_important_parameters():
                if p.grad is not None:
                    fisher_new[n] += p.grad.detach() ** 2 / n_samples
        for n, p in model.named_important_parameters():
            self.fisher[n] = self.fisher.get(n, 0.0) + fisher_new[n]
            self.opt_params[n] = p.detach().clone()
        model.zero_grad(set_to_none=True)

class SI:
    def __init__(self, lam=1.0, epsilon=1e-3, track_equivalence=False):
        self.lam, self.epsilon = lam, epsilon
        self.omega, self.prev_task_params = {}, {}
        self._w, self._prev_step_params = {}, {}
        self.track_equivalence = track_equivalence
        self._w64, self.equivalence_log, self._task_idx = {}, [], 0
    def before_task(self, model):
        self._w = {n: torch.zeros_like(p) for n, p in model.named_important_parameters()}
        if self.track_equivalence:
            self._w64 = {n: torch.zeros_like(p, dtype=torch.float64) for n, p in model.named_important_parameters()}
        self._prev_step_params = {n: p.detach().clone() for n, p in model.named_important_parameters()}
        if not self.prev_task_params:
            self.prev_task_params = {n: p.detach().clone() for n, p in model.named_important_parameters()}
        self._task_idx += 1
    def accumulate_step(self, model):
        for n, p in model.named_important_parameters():
            delta = p.detach() - self._prev_step_params[n]
            grad = p.grad.detach() if p.grad is not None else torch.zeros_like(p)
            contrib = -grad * delta
            self._w[n] += contrib.float()
            if self.track_equivalence:
                self._w64[n] += contrib.double()
            self._prev_step_params[n] = p.detach().clone()
    def penalty(self, model):
        if not self.omega:
            return torch.tensor(0.0, device=DEVICE)
        loss = 0.0
        for n, p in model.named_important_parameters():
            if n in self.omega:
                loss = loss + (self.omega[n] * (p - self.prev_task_params[n]).pow(2)).sum()
        return self.lam * loss
    def after_task(self, model, *args):
        rel_devs = []
        for n, p in model.named_important_parameters():
            denom = (p.detach() - self.prev_task_params[n]).pow(2) + self.epsilon
            omega_add_f32 = self._w[n] / denom
            self.omega[n] = self.omega.get(n, 0.0) + omega_add_f32
            if self.track_equivalence:
                omega_add_f64 = self._w64[n] / denom.double()
                rel_devs.append(((omega_add_f32.double() - omega_add_f64).abs() / (omega_add_f64.abs() + 1e-12)).flatten())
            self.prev_task_params[n] = p.detach().clone()
        if self.track_equivalence and rel_devs:
            all_rel = torch.cat(rel_devs)
            self.equivalence_log.append(dict(domain_boundary=self._task_idx,
                                             mean_relative_deviation=float(all_rel.mean().item()),
                                             max_relative_deviation=float(all_rel.max().item())))

class LWF:
    def __init__(self, lam=1.0, temperature=2.0):
        self.lam, self.T, self.old_model = lam, temperature, None
    def before_task(self, model): pass
    def distillation_loss(self, model, x_batch):
        if self.old_model is None or x_batch.shape[0] == 0:
            return torch.tensor(0.0, device=DEVICE)
        with torch.no_grad():
            old_probs = F.softmax(self.old_model(x_batch) / self.T, dim=1)
        new_logprobs = F.log_softmax(model(x_batch) / self.T, dim=1)
        return self.lam * F.kl_div(new_logprobs, old_probs, reduction="batchmean") * (self.T ** 2)
    def after_task(self, model, *args):
        import copy
        self.old_model = copy.deepcopy(model)
        for p in self.old_model.parameters():
            p.requires_grad = False

# ==============================================================================
# 6. REPLAY MEMORIES
# ==============================================================================
class ExperienceReplay:
    name = "ER"
    def __init__(self, total_cap: int = REPLAY_CAP_M):
        self.total_cap = total_cap
        self.buffer_x, self.buffer_y = [], []
    def update_after_task(self, x_train, y_train, task_id):
        per_domain_cap = max(1, self.total_cap // (len(self.buffer_x) + 1))
        for k in range(len(self.buffer_x)):
            if self.buffer_x[k].shape[0] > per_domain_cap:
                idx = torch.randperm(self.buffer_x[k].shape[0], device=self.buffer_x[k].device)[:per_domain_cap]
                self.buffer_x[k], self.buffer_y[k] = self.buffer_x[k][idx], self.buffer_y[k][idx]
        idx = torch.randperm(x_train.shape[0], device=x_train.device)[:per_domain_cap]
        self.buffer_x.append(x_train[idx].clone())
        self.buffer_y.append(y_train[idx].clone())
    def get_replay_batch(self, max_size: int):
        if not self.buffer_x:
            return None, None
        x, y = torch.cat(self.buffer_x, dim=0), torch.cat(self.buffer_y, dim=0)
        if x.shape[0] > max_size:
            idx = torch.randperm(x.shape[0], device=x.device)[:max_size]
            x, y = x[idx], y[idx]
        return x, y
    def storage_bytes(self):
        if not self.buffer_x:
            return 0
        x, y = torch.cat(self.buffer_x, dim=0), torch.cat(self.buffer_y, dim=0)
        return x.element_size() * x.nelement() + y.element_size() * y.nelement()

class GenerativeReplayEnsemble:
    def __init__(self, gen_cls, n_features, use_dp=False, gen_epochs=GEN_EPOCHS, lr=GEN_LR,
                 dp_clip_norm=DP_CLIP_NORM, dp_noise_multiplier=1.0, dp_sample_rate=DP_SAMPLE_RATE, **gen_kwargs):
        self.gen_cls, self.n_features, self.use_dp = gen_cls, n_features, use_dp
        self.gen_epochs, self.lr = gen_epochs, lr
        self.dp_clip_norm, self.dp_noise_multiplier, self.dp_sample_rate = dp_clip_norm, dp_noise_multiplier, dp_sample_rate
        self.gen_kwargs = gen_kwargs
        self.generators: List[nn.Module] = []
        self.label_priors: List[torch.Tensor] = []
        self.accountant = RDPPrivacyAccountant() if use_dp else None
    def _train_one(self, x_train, y_train):
        if self.gen_cls is ConditionalGANGenerator:
            return self._train_gan(x_train, y_train)
        gen = self.gen_cls(self.n_features, **self.gen_kwargs).to(DEVICE)
        if self.use_dp:
            dp_train_generator_loss_model(gen, x_train, y_train, self.gen_epochs, self.lr, self.dp_clip_norm,
                                          self.dp_noise_multiplier, self.dp_sample_rate, self.accountant)
        else:
            opt = torch.optim.Adam(gen.parameters(), lr=self.lr)
            for _ in range(self.gen_epochs):
                opt.zero_grad()
                gen.loss(x_train, y_train).backward()
                torch.nn.utils.clip_grad_norm_(gen.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
                opt.step()
        gen.eval()
        return gen
    def _train_gan(self, x_train, y_train):
        latent_dim = self.gen_kwargs.get("latent_dim", 8)
        hidden = self.gen_kwargs.get("hidden", 32)
        g = ConditionalGANGenerator(self.n_features, latent_dim=latent_dim, hidden=hidden).to(DEVICE)
        d = ConditionalGANDiscriminator(self.n_features, hidden=hidden).to(DEVICE)
        opt_g = torch.optim.Adam(g.parameters(), lr=self.lr, betas=(0.5, 0.9))
        opt_d = torch.optim.Adam(d.parameters(), lr=self.lr, betas=(0.5, 0.9))
        bce = nn.BCEWithLogitsLoss()
        n = x_train.shape[0]
        for _ in range(self.gen_epochs):
            z = torch.randn(n, g.latent_dim, device=x_train.device)
            with torch.no_grad():
                fake = g(z, y_train)
            if not self.use_dp:
                opt_d.zero_grad()
                real_logits, fake_logits = d(x_train, y_train), d(fake, y_train)
                d_loss = bce(real_logits, torch.ones_like(real_logits)) + bce(fake_logits, torch.zeros_like(fake_logits))
                d_loss.backward()
                torch.nn.utils.clip_grad_norm_(d.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
                opt_d.step()
            else:
                idx = poisson_subsample_indices(n, self.dp_sample_rate)
                x_sub, y_sub = x_train[idx], y_train[idx]
                params = [p for p in d.parameters() if p.requires_grad]
                grads_list = []
                for i in range(x_sub.shape[0]):
                    d.zero_grad(set_to_none=True)
                    rl = d(x_sub[i:i + 1], y_sub[i:i + 1])
                    g_i = torch.autograd.grad(bce(rl, torch.ones_like(rl)), params, retain_graph=False)
                    grads_list.append([gi.detach().clone() for gi in g_i])
                noised_real = clip_and_noise(grads_list, params, self.dp_clip_norm, self.dp_noise_multiplier)
                d.zero_grad(set_to_none=True)
                fl = d(fake, y_train)
                bce(fl, torch.zeros_like(fl)).backward()
                for p, g_real in zip(params, noised_real):
                    p.grad = (p.grad if p.grad is not None else torch.zeros_like(p)) + g_real
                torch.nn.utils.clip_grad_norm_(d.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
                opt_d.step()
                self.accountant.step(noise_multiplier=self.dp_noise_multiplier, sample_rate=self.dp_sample_rate)
            opt_g.zero_grad()
            z = torch.randn(n, g.latent_dim, device=x_train.device)
            gl = d(g(z, y_train), y_train)
            bce(gl, torch.ones_like(gl)).backward()
            torch.nn.utils.clip_grad_norm_(g.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
            opt_g.step()
        g.eval()
        return g
    def update_after_task(self, x_train, y_train, task_id):
        self.generators.append(self._train_one(x_train, y_train))
        classes, counts = torch.unique(y_train, return_counts=True)
        prior = torch.zeros(int(classes.max().item()) + 1, device=DEVICE)
        prior[classes] = counts.float() / counts.sum()
        self.label_priors.append(prior)
    def get_replay_batch(self, max_size: int):
        if not self.generators:
            return None, None
        per_draw = max(1, max_size // len(self.generators))
        xs, ys = [], []
        for gen, prior in zip(self.generators, self.label_priors):
            y_s = torch.multinomial(prior, per_draw, replacement=True)
            with torch.no_grad():
                xs.append(gen.sample(y_s))
            ys.append(y_s)
        return torch.cat(xs, dim=0), torch.cat(ys, dim=0)
    def storage_bytes(self):
        return sum(p.element_size() * p.nelement() for gen in self.generators for p in gen.parameters())
    def privacy_epsilon(self, delta=DP_DELTA):
        if not self.use_dp or self.accountant is None or self.accountant.steps_taken == 0:
            return float("inf")
        return self.accountant.get_epsilon(delta=delta)

class ZeroTrustReplayEnsemble:
    """Zero-Trust Replay (ZTR): independent holdout verifier + continuous re-verification of every
    replayed synthetic sample + honest DP composition of the verifier release."""
    def __init__(self, base_gen_cls, n_features, use_dp=False, dp_eps_star=None,
                 dp_sample_rate=DP_SAMPLE_RATE, dp_delta=DP_DELTA, n_tasks_estimate=10,
                 gen_epochs=GEN_EPOCHS, lr=GEN_LR, holdout_frac=ZT_HOLDOUT_FRAC,
                 trust_threshold=ZT_TRUST_THRESHOLD, oversample_factor=ZT_OVERSAMPLE_FACTOR,
                 verifier_budget_fraction=ZT_VERIFIER_DP_BUDGET_FRACTION, **gen_kwargs):
        gen_noise_mult, verifier_noise_mult = 1.0, 0.0
        if use_dp:
            gen_eps = dp_eps_star * (1.0 - verifier_budget_fraction)
            verifier_eps = dp_eps_star * verifier_budget_fraction
            gen_noise_mult = calibrate_noise_multiplier(gen_eps, dp_sample_rate, gen_epochs * n_tasks_estimate, dp_delta)
            verifier_noise_mult = calibrate_noise_multiplier(verifier_eps, 1.0, n_tasks_estimate, dp_delta)
        self.base = GenerativeReplayEnsemble(base_gen_cls, n_features, use_dp=use_dp, gen_epochs=gen_epochs, lr=lr,
                                             dp_clip_norm=DP_CLIP_NORM, dp_noise_multiplier=gen_noise_mult,
                                             dp_sample_rate=dp_sample_rate, **gen_kwargs)
        self.n_features, self.use_dp = n_features, use_dp
        self.holdout_frac, self.trust_threshold = holdout_frac, trust_threshold
        self.oversample_factor = oversample_factor
        self.verifier_noise_multiplier = verifier_noise_mult
        self.verifiers: List[dict] = []
        self.rejection_log: List[dict] = []
        self._last_filter_stats = {}
    @property
    def generators(self): return self.base.generators
    @property
    def label_priors(self): return self.base.label_priors
    @property
    def accountant(self): return self.base.accountant
    def update_after_task(self, x_train, y_train, task_id):
        n = x_train.shape[0]
        perm = torch.randperm(n, device=x_train.device)
        n_holdout = max(2, int(n * self.holdout_frac))
        holdout_idx, train_idx = perm[:n_holdout], perm[n_holdout:]
        x_hold, y_hold = x_train[holdout_idx], y_train[holdout_idx]
        x_gen_train, y_gen_train = x_train[train_idx], y_train[train_idx]
        self.base.update_after_task(x_gen_train, y_gen_train, task_id)
        n_classes = int(max(y_train.max().item(), 1)) + 1
        mu = torch.zeros(n_classes, self.n_features, device=DEVICE)
        for c in range(n_classes):
            mask = y_hold == c
            n_c = int(mask.sum().item())
            mu_c = x_hold[mask].mean(dim=0) if n_c > 0 else torch.zeros(self.n_features, device=DEVICE)
            n_c = max(n_c, 1)
            if self.use_dp:
                mu_c = mu_c + torch.randn_like(mu_c) * self.verifier_noise_multiplier * ((2.0 * Z_SCORE_CLIP) / n_c)
            mu[c] = mu_c
        self.verifiers.append({"mu": mu})
        if self.use_dp:
            self.base.accountant.step(noise_multiplier=self.verifier_noise_multiplier, sample_rate=1.0)
        self.rejection_log.append(dict(task_id=task_id, n_holdout=n_holdout, n_generator_train=int(x_gen_train.shape[0])))
    def score_batch(self, gen_idx, x, y):
        z = x - self.verifiers[gen_idx]["mu"][y]
        return torch.exp(-0.5 * z.pow(2).mean(dim=1))
    def get_replay_batch_weighted(self, max_size: int):
        if not self.generators:
            return None, None, None
        per_draw = max(1, (max_size * self.oversample_factor) // len(self.generators))
        xs, ys, ws = [], [], []
        n_candidates, n_kept = 0, 0
        for g_idx, (gen, prior) in enumerate(zip(self.generators, self.label_priors)):
            y_s = torch.multinomial(prior, per_draw, replacement=True)
            with torch.no_grad():
                x_s = gen.sample(y_s)
            score = self.score_batch(g_idx, x_s, y_s)
            keep = score >= self.trust_threshold
            n_candidates += x_s.shape[0]
            n_kept += int(keep.sum().item())
            if keep.any():
                xs.append(x_s[keep]); ys.append(y_s[keep]); ws.append(score[keep])
        self._last_filter_stats = dict(n_candidates=n_candidates, n_kept=n_kept,
                                       keep_rate=(n_kept / n_candidates if n_candidates else float("nan")))
        if not xs:
            return None, None, None
        x_all, y_all, w_all = torch.cat(xs), torch.cat(ys), torch.cat(ws)
        if x_all.shape[0] > max_size:
            top = torch.argsort(w_all, descending=True)[:max_size]
            x_all, y_all, w_all = x_all[top], y_all[top], w_all[top]
        return x_all, y_all, w_all
    def get_replay_batch(self, max_size: int):
        x, y, _ = self.get_replay_batch_weighted(max_size)
        return x, y
    def storage_bytes(self):
        return self.base.storage_bytes() + sum(v["mu"].element_size() * v["mu"].nelement() for v in self.verifiers)
    def privacy_epsilon(self, delta=DP_DELTA):
        return self.base.privacy_epsilon(delta=delta)

class PoisonedGeneratorWrapper(nn.Module):
    """Simulated compromised generator: label-flip poisoning via the replay channel."""
    def __init__(self, clean_gen: nn.Module, poison_rate: float, n_classes: int = 2):
        super().__init__()
        self.clean_gen, self.poison_rate, self.n_classes = clean_gen, poison_rate, n_classes
    @torch.no_grad()
    def sample_with_mask(self, y):
        flip_mask = torch.rand(y.shape[0], device=y.device) < self.poison_rate
        y_query = torch.where(flip_mask, (self.n_classes - 1) - y, y)
        return self.clean_gen.sample(y_query), flip_mask

class NoisyBufferReplay(ExperienceReplay):
    def __init__(self, total_cap, noise_multiplier, clip_norm=DP_CLIP_NORM):
        super().__init__(total_cap=total_cap)
        self.noise_multiplier, self.clip_norm = noise_multiplier, clip_norm
        self.accountant = RDPPrivacyAccountant()
    def get_replay_batch(self, max_size: int):
        x, y = super().get_replay_batch(max_size)
        if x is None:
            return None, None
        norms = x.norm(dim=1, keepdim=True)
        x_clipped = x * torch.clamp(self.clip_norm / (norms + 1e-6), max=1.0)
        x_noised = x_clipped + torch.randn_like(x_clipped) * self.noise_multiplier * self.clip_norm
        self.accountant.step(noise_multiplier=self.noise_multiplier, sample_rate=1.0)
        return x_noised, y
    def privacy_epsilon(self, delta=DP_DELTA):
        return self.accountant.get_epsilon(delta=delta) if self.accountant.steps_taken else float("inf")

def detection_metrics(model, x_test, y_test) -> Dict[str, float]:
    model.eval()
    with torch.no_grad():
        logits = model(x_test)
        probs = torch.softmax(logits, dim=1)[:, 1].cpu().numpy()
        preds = logits.argmax(dim=1).cpu().numpy()
    y = y_test.cpu().numpy()
    acc = accuracy_score(y, preds)
    try:
        auc = roc_auc_score(y, probs) if len(np.unique(y)) > 1 else float("nan")
    except ValueError:
        auc = float("nan")
    return dict(accuracy=acc, roc_auc=auc, probs=probs, labels=y)

def random_init_baseline_accuracy(n_features: int, task: TaskData, n_reps: int = 3) -> float:
    accs = []
    for r in range(n_reps):
        torch.manual_seed(90000 + r)
        m = AttentionTabularClassifier(n_features).to(DEVICE)
        accs.append(detection_metrics(m, task.x_test, task.y_test)["accuracy"])
    return float(np.mean(accs))

def build_method(method_name: str, n_features: int, dp_eps_star: Optional[float] = None,
                 replay_cap: int = REPLAY_CAP_M, n_tasks_estimate: int = 10):
    if method_name == "FineTune": return None, None
    if method_name == "ER": return None, ExperienceReplay(total_cap=replay_cap)
    if method_name == "EWC": return EWC(lam=500.0), None
    if method_name == "SI": return SI(lam=1.0, track_equivalence=True), None
    if method_name == "LWF": return LWF(lam=1.0), None
    if method_name in GENERATIVE_METHODS:
        base_family_map = {"GMR-VAE": VAEGenerator, "GMR-GAN": ConditionalGANGenerator, "GMR-Diffusion": DiffusionGenerator}
        use_dp = dp_eps_star is not None and np.isfinite(dp_eps_star)
        if method_name.endswith(ZT_SUFFIX):
            base_name = method_name[:-len(ZT_SUFFIX)]
            extra = dict(T=DIFFUSION_T) if base_name == "GMR-Diffusion" else dict()
            return None, ZeroTrustReplayEnsemble(base_family_map[base_name], n_features, use_dp=use_dp,
                                                 dp_eps_star=(dp_eps_star if use_dp else None),
                                                 dp_sample_rate=DP_SAMPLE_RATE, dp_delta=DP_DELTA,
                                                 n_tasks_estimate=n_tasks_estimate, gen_epochs=GEN_EPOCHS,
                                                 lr=GEN_LR, **extra)
        noise_mult = 1.0
        if use_dp:
            noise_mult = calibrate_noise_multiplier(dp_eps_star, DP_SAMPLE_RATE, GEN_EPOCHS * n_tasks_estimate, DP_DELTA)
        extra = dict(T=DIFFUSION_T) if method_name == "GMR-Diffusion" else dict()
        return None, GenerativeReplayEnsemble(base_family_map[method_name], n_features, use_dp=use_dp,
                                              dp_noise_multiplier=noise_mult, **extra)
    if method_name == "DP-ER":
        noise_mult = calibrate_noise_multiplier(dp_eps_star, DP_SAMPLE_RATE, n_tasks_estimate * EPOCHS_PER_DOMAIN, DP_DELTA)
        return None, NoisyBufferReplay(total_cap=replay_cap, noise_multiplier=noise_mult)
    raise ValueError(method_name)

def run_zero_trust_robustness_trial(method_name, tasks, seed, poison_rate, dp_eps_star=None,
                                    epochs_per_domain=EPOCHS_PER_DOMAIN, replay_cap=REPLAY_CAP_M):
    torch.manual_seed(seed); np.random.seed(seed)
    n_features = tasks[0].n_features
    model = AttentionTabularClassifier(n_features).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    _, replay = build_method(method_name, n_features, dp_eps_star=dp_eps_star, replay_cap=replay_cap,
                             n_tasks_estimate=len(tasks))
    is_zt = hasattr(replay, "score_batch")
    K = len(tasks)
    R = np.full((K, K), np.nan)
    poisoned_seen, poisoned_kept = 0, 0
    for i, task in enumerate(tasks):
        x_cur, y_cur = task.x_train, task.y_train
        for epoch in range(epochs_per_domain):
            x_rep, y_rep, w_rep = None, None, None
            if replay is not None and getattr(replay, "generators", None):
                per_draw = max(1, (replay_cap * (replay.oversample_factor if is_zt else 1)) // len(replay.generators))
                xs, ys, ws = [], [], []
                for g_idx, (gen, prior) in enumerate(zip(replay.generators, replay.label_priors)):
                    y_s = torch.multinomial(prior, per_draw, replacement=True)
                    if g_idx == 0 and i >= 1:
                        x_s, flip_mask = PoisonedGeneratorWrapper(gen, poison_rate).sample_with_mask(y_s)
                        poisoned_seen += int(flip_mask.sum().item())
                    else:
                        flip_mask = torch.zeros(y_s.shape[0], dtype=torch.bool, device=y_s.device)
                        with torch.no_grad():
                            x_s = gen.sample(y_s)
                    if is_zt:
                        score = replay.score_batch(g_idx, x_s, y_s)
                        keep = score >= replay.trust_threshold
                        poisoned_kept += int((flip_mask & keep).sum().item())
                        x_s, y_s_keep, w_s = x_s[keep], y_s[keep], score[keep]
                    else:
                        y_s_keep, w_s = y_s, torch.ones(x_s.shape[0], device=x_s.device)
                    if x_s.shape[0] > 0:
                        xs.append(x_s); ys.append(y_s_keep); ws.append(w_s)
                if xs:
                    x_rep, y_rep, w_rep = torch.cat(xs), torch.cat(ys), torch.cat(ws)
            optimizer.zero_grad()
            loss = F.cross_entropy(model(x_cur), y_cur)
            if x_rep is not None and x_rep.shape[0] > 0:
                lam_i = x_rep.shape[0] / (x_cur.shape[0] + x_rep.shape[0])
                per_sample = F.cross_entropy(model(x_rep), y_rep, reduction="none")
                loss_rep = (per_sample * w_rep).sum() / w_rep.sum().clamp_min(1e-6)
                loss = (1 - lam_i) * loss + lam_i * loss_rep
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
            optimizer.step()
        if replay is not None:
            replay.update_after_task(x_cur, y_cur, i)
        for j in range(i + 1):
            R[i, j] = detection_metrics(model, tasks[j].x_test, tasks[j].y_test)["accuracy"]
    ACC = float(np.mean(R[K - 1, :]))
    BWT = float(np.mean([R[K - 1, j] - R[j, j] for j in range(K - 1)])) if K > 1 else 0.0
    rej = ((poisoned_seen - poisoned_kept) / poisoned_seen) if poisoned_seen > 0 else float("nan")
    return dict(ACC=ACC, BWT=BWT, poisoned_seen=poisoned_seen, poisoned_kept=poisoned_kept,
                poisoned_rejection_rate=rej)

def run_domain_incremental(method_name: str, tasks: List[TaskData], seed: int,
                           dp_eps_star: Optional[float] = None, track_curves: bool = False,
                           replay_cap: int = REPLAY_CAP_M, epochs_per_domain: int = EPOCHS_PER_DOMAIN,
                           baseline_accs: Optional[Dict[str, float]] = None):
    torch.manual_seed(seed); np.random.seed(seed)
    n_features = tasks[0].n_features
    model = AttentionTabularClassifier(n_features).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    cl_reg, replay = build_method(method_name, n_features, dp_eps_star=dp_eps_star,
                                  replay_cap=replay_cap, n_tasks_estimate=len(tasks))
    K = len(tasks)
    R = np.full((K, K), np.nan)
    curves = {} if track_curves else None
    for i, task in enumerate(tasks):
        x_cur, y_cur = task.x_train, task.y_train
        if i > 0:
            R[i - 1, i] = detection_metrics(model, task.x_test, task.y_test)["accuracy"]
        if cl_reg is not None:
            cl_reg.before_task(model)
        epoch_accs = []
        for epoch in range(epochs_per_domain):
            w_rep = None
            if replay is not None:
                if hasattr(replay, "get_replay_batch_weighted"):
                    x_rep, y_rep, w_rep = replay.get_replay_batch_weighted(replay_cap)
                else:
                    x_rep, y_rep = replay.get_replay_batch(replay_cap)
            else:
                x_rep, y_rep = None, None
            optimizer.zero_grad()
            loss_cur = F.cross_entropy(model(x_cur), y_cur)
            if x_rep is not None and x_rep.shape[0] > 0:
                lam_i = x_rep.shape[0] / (x_cur.shape[0] + x_rep.shape[0])
                logits_rep = model(x_rep)
                if w_rep is not None:
                    ps = F.cross_entropy(logits_rep, y_rep, reduction="none")
                    loss_rep = (ps * w_rep).sum() / w_rep.sum().clamp_min(1e-6)
                else:
                    loss_rep = F.cross_entropy(logits_rep, y_rep)
                loss = (1 - lam_i) * loss_cur + lam_i * loss_rep
            else:
                loss = loss_cur
            if isinstance(cl_reg, (EWC, SI)):
                loss = loss + cl_reg.penalty(model)
            if isinstance(cl_reg, LWF):
                loss = loss + cl_reg.distillation_loss(model, x_cur)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
            optimizer.step()
            if isinstance(cl_reg, SI):
                cl_reg.accumulate_step(model)
            if track_curves:
                epoch_accs.append(detection_metrics(model, task.x_test, task.y_test)["accuracy"])
        if track_curves:
            curves[task.name] = epoch_accs
        if cl_reg is not None:
            cl_reg.after_task(model, x_cur, y_cur)
        if replay is not None:
            replay.update_after_task(x_cur, y_cur, i)
        for j in range(i + 1):
            R[i, j] = detection_metrics(model, tasks[j].x_test, tasks[j].y_test)["accuracy"]
    ACC = float(np.mean(R[K - 1, :]))
    BWT = float(np.mean([R[K - 1, j] - R[j, j] for j in range(K - 1)])) if K > 1 else 0.0
    if baseline_accs is not None and K > 1:
        FWT = float(np.mean([R[j - 1, j] - baseline_accs[tasks[j].name] for j in range(1, K)]))
    else:
        FWT = 0.0
    return dict(method=method_name, seed=seed, R=R, ACC=ACC, BWT=BWT, FWT=FWT, curves=curves,
                model=model, replay=replay, cl_reg=cl_reg,
                x_members=torch.cat([t.x_train for t in tasks]), y_members=torch.cat([t.y_train for t in tasks]),
                x_nonmembers=torch.cat([t.x_test for t in tasks]), y_nonmembers=torch.cat([t.y_test for t in tasks]))

def flow_key_composition_audit(tasks: List[TaskData]) -> pd.DataFrame:
    rows = []
    key_sets = [set(t.flow_keys_train) for t in tasks]
    keyspace = 2 ** 64
    for i in range(2, len(tasks) + 1):
        for j in range(1, i):
            overlap = key_sets[i - 1] & key_sets[j - 1]
            n = max(len(key_sets[i - 1]), len(key_sets[j - 1]))
            collision_p = 1 - math.exp(-(n ** 2) / (2 * keyspace)) if n > 0 else 0.0
            rows.append(dict(domain_i=i, domain_j=j, status="sequential" if overlap else "disjoint-confirmed",
                             hash_function="SHA-256 (64-bit truncated)",
                             collision_probability_at_observed_keyspace=f"~{collision_p:.1e}",
                             affects_privacy_composition_accounting=bool(overlap)))
    return pd.DataFrame(rows)

def summarize_and_test(raw_by_method_seed, dataset_name: str) -> pd.DataFrame:
    proposed_vals = {s: raw_by_method_seed[PROPOSED_METHOD][s]["ACC"] for s in raw_by_method_seed[PROPOSED_METHOD]}
    stats_by_method, raw_p, methods_with_p = {}, [], []
    for method in METHOD_ORDER:
        sd = raw_by_method_seed[method]
        acc = np.array([sd[s]["ACC"] for s in sd]); bwt = np.array([sd[s]["BWT"] for s in sd])
        fwt = np.array([sd[s]["FWT"] for s in sd])
        entry = dict(ACC_mean=round(float(acc.mean()), 3), ACC_std=round(float(acc.std()), 3),
                     BWT_mean=round(float(bwt.mean()), 3), BWT_std=round(float(bwt.std()), 3),
                     FWT_mean=round(float(fwt.mean()), 3), FWT_std=round(float(fwt.std()), 3),
                     p_vs_proposed_raw=np.nan, cohens_d_vs_proposed=np.nan, p_holm_bonferroni=np.nan,
                     significant_at_0_05=None, practically_meaningful=None)
        if method != PROPOSED_METHOD:
            common = sorted(set(sd.keys()) & set(proposed_vals.keys()))
            a = np.array([proposed_vals[s] for s in common]); b = np.array([sd[s]["ACC"] for s in common])
            try:
                _, p = stats.wilcoxon(a, b)
            except ValueError:
                p = float("nan")
            pooled = np.sqrt((a.var(ddof=1) + b.var(ddof=1)) / 2) if len(a) > 1 else 0
            d = float((a.mean() - b.mean()) / pooled) if pooled > 0 else float("nan")
            entry["p_vs_proposed_raw"] = round(float(p), 4)
            entry["cohens_d_vs_proposed"] = round(d, 3)
            raw_p.append(p); methods_with_p.append(method)
        stats_by_method[method] = entry
    if raw_p:
        p_arr = np.nan_to_num(np.array(raw_p, dtype=float), nan=1.0)
        reject, p_corr, _, _ = multipletests(p_arr, alpha=0.05, method="holm")
        for method, p_c, rej in zip(methods_with_p, p_corr, reject):
            e = stats_by_method[method]
            e["p_holm_bonferroni"] = round(float(p_c), 4)
            e["significant_at_0_05"] = bool(rej)
            e["practically_meaningful"] = bool(abs(e["cohens_d_vs_proposed"]) > 0.5) if not math.isnan(e["cohens_d_vs_proposed"]) else False
    rows = []
    for method in METHOD_ORDER:
        e = stats_by_method[method]
        rows.append({"Dataset": dataset_name, "Method": method,
                     "ACC_mean": e["ACC_mean"], "ACC_std": e["ACC_std"], "BWT_mean": e["BWT_mean"],
                     "BWT_std": e["BWT_std"], "FWT_mean": e["FWT_mean"], "FWT_std": e["FWT_std"],
                     "p_vs_proposed_raw": e["p_vs_proposed_raw"], "cohens_d_vs_proposed": e["cohens_d_vs_proposed"],
                     "p_holm_bonferroni": e["p_holm_bonferroni"], "significant_at_0.05": e["significant_at_0_05"],
                     "practically_meaningful_|d|>0.5": e["practically_meaningful"],
                     "proposed_method": (method == PROPOSED_METHOD)})
    return pd.DataFrame(rows)

def classifier_mia_advantage(model, x_members, y_members, x_nonmembers, y_nonmembers, seed=0) -> float:
    g = torch.Generator().manual_seed(seed)
    n = min(x_members.shape[0], x_nonmembers.shape[0])
    idx_m = torch.randperm(x_members.shape[0], generator=g)[:n].to(x_members.device)
    idx_n = torch.randperm(x_nonmembers.shape[0], generator=g)[:n].to(x_nonmembers.device)
    model.eval()
    with torch.no_grad():
        loss_m = F.cross_entropy(model(x_members[idx_m]), y_members[idx_m], reduction="none").cpu().numpy()
        loss_n = F.cross_entropy(model(x_nonmembers[idx_n]), y_nonmembers[idx_n], reduction="none").cpu().numpy()
    scores = np.concatenate([-loss_m, -loss_n])
    labels = np.concatenate([np.ones_like(loss_m), np.zeros_like(loss_n)])
    try:
        auc = roc_auc_score(labels, scores)
    except ValueError:
        auc = 0.5
    return float(2 * auc - 1)

# ==============================================================================
# 7. ATTRIBUTION / EXPLAINABILITY HELPERS
# ==============================================================================
def attention_gradient_importance(model, x_sample, target_class: int) -> np.ndarray:
    model.zero_grad(set_to_none=True)
    tok = model.tokenize(x_sample)
    tok.retain_grad()
    pooled, attn_w = model.encode_tokens(tok)
    model.cls_head(pooled)[0, target_class].backward()
    imp = (attn_w[0].mean(dim=0) * tok.grad[0].norm(dim=-1)).detach().cpu().numpy()
    total = imp.sum()
    return imp / total if total > 1e-12 else imp

def integrated_gradients_importance(model, x_sample, baseline, target_class: int, steps: int = 32) -> np.ndarray:
    alphas = torch.linspace(0, 1, steps, device=x_sample.device).view(-1, 1)
    path = (baseline + alphas * (x_sample - baseline)).detach().requires_grad_(True)
    grads = torch.autograd.grad(model(path)[:, target_class].sum(), path)[0]
    imp = (grads.mean(dim=0) * (x_sample - baseline).squeeze(0)).abs().detach().cpu().numpy()
    total = imp.sum()
    return imp / total if total > 1e-12 else imp

def deletion_insertion_curve(model, x_sample, order: np.ndarray, reference: torch.Tensor):
    with torch.no_grad():
        x_del = x_sample.clone()
        del_probs = [float(torch.softmax(model(x_del), dim=1)[0, 1])]
        for f in order:
            x_del[0, f] = reference[f]
            del_probs.append(float(torch.softmax(model(x_del), dim=1)[0, 1]))
        x_ins = reference.clone().unsqueeze(0)
        ins_probs = [float(torch.softmax(model(x_ins), dim=1)[0, 1])]
        for f in order:
            x_ins[0, f] = x_sample[0, f]
            ins_probs.append(float(torch.softmax(model(x_ins), dim=1)[0, 1]))
    return np.array(del_probs), np.array(ins_probs)

def _trapz_auc(probs: np.ndarray) -> float:
    fn = getattr(np, "trapezoid", None) or np.trapz
    return float(fn(probs, np.linspace(0, 1, len(probs))))

def evaluate_faithfulness_per_domain(final_model, tasks, K: int, n_probes: int = 32, seed: int = 0) -> pd.DataFrame:
    rng = np.random.RandomState(seed)
    final_model.eval()
    rows = []
    for j, task in enumerate(tasks):
        y_np = task.y_test.cpu().numpy()
        benign = y_np == 0
        reference = task.x_test[benign].median(dim=0).values if benign.any() else task.x_test.median(dim=0).values
        attack_idx = np.where(y_np == 1)[0]
        probe_idx = rng.choice(attack_idx, size=min(n_probes, len(attack_idx)), replace=False)
        del_m, ins_m, del_r, ins_r = [], [], [], []
        for idx in probe_idx:
            xs = task.x_test[idx:idx + 1]
            order = np.argsort(-attention_gradient_importance(final_model, xs, target_class=1))
            rand_order = rng.permutation(task.n_features)
            d_m, i_m = deletion_insertion_curve(final_model, xs, order, reference)
            d_r, i_r = deletion_insertion_curve(final_model, xs, rand_order, reference)
            del_m.append(_trapz_auc(d_m)); ins_m.append(_trapz_auc(i_m))
            del_r.append(_trapz_auc(d_r)); ins_r.append(_trapz_auc(i_r))
        rows.append(dict(Domain=j + 1, domains_elapsed_since_trained=(K - 1) - j,
                         deletion_AUC_method=round(float(np.mean(del_m)), 3),
                         deletion_AUC_random=round(float(np.mean(del_r)), 3),
                         insertion_AUC_method=round(float(np.mean(ins_m)), 3),
                         insertion_AUC_random=round(float(np.mean(ins_r)), 3),
                         note="Sensitivity indicators (deletion/insertion AUC), not causal explanations"))
    return pd.DataFrame(rows)

# ==============================================================================
# ============================  EXPERIMENT STAGES  ============================
# ==============================================================================
tasks_ds = DATASETS[DATASET_NAME]
n_features = tasks_ds[0].n_features

print("\n" + "=" * 78); print("STAGE 1/9 -- Main continual-learning comparison (Table 2)"); print("=" * 78)
CURVE_METHODS = ["FineTune", "EWC", "ER", "GMR-GAN"]
_STAGE_ID = "01_main_comparison"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID)
    main_raw, baseline_acc_by_dataset, curves_raw, table2 = _c["main_raw"], _c["baseline_acc_by_dataset"], _c["curves_raw"], _c["table2"]
else:
    main_raw, baseline_acc_by_dataset, curves_raw = {}, {}, {}
    for dataset_name, tasks in DATASETS.items():
        print(f"-- dataset: {dataset_name} --")
        baseline_acc_by_dataset[dataset_name] = cached_unit(
            f"s1__baseline__{dataset_name}",
            lambda: {t.name: random_init_baseline_accuracy(tasks[0].n_features, t) for t in tasks})
        main_raw[dataset_name] = {m: {} for m in METHOD_ORDER}
        curves_raw[dataset_name] = {m: {} for m in CURVE_METHODS}
        for method in METHOD_ORDER:
            for seed in SEEDS_MAIN:
                def _run():
                    r = run_domain_incremental(method, tasks, seed, track_curves=(method in CURVE_METHODS),
                                               baseline_accs=baseline_acc_by_dataset[dataset_name])
                    return dict(ACC=r["ACC"], BWT=r["BWT"], FWT=r["FWT"], R=r["R"].tolist(), curves=r["curves"],
                                si_equivalence=(r["cl_reg"].equivalence_log if isinstance(r["cl_reg"], SI) else None))
                u = cached_unit(f"s1__{dataset_name}__{method}__seed{seed}", _run)
                main_raw[dataset_name][method][seed] = {k: v for k, v in u.items() if k != "curves"}
                if method in CURVE_METHODS:
                    curves_raw[dataset_name][method][seed] = u["curves"]
                print(f"    {dataset_name:12s} {method:18s} seed={seed} ACC={u['ACC']:.3f} BWT={u['BWT']:.3f} FWT={u['FWT']:.3f}")
                gc.collect()
        log_memory(f"after {dataset_name}")
    save_raw(main_raw, "main_comparison_raw"); save_raw(curves_raw, "learning_curves_raw")
    save_raw(baseline_acc_by_dataset, "fwt_random_baselines_raw")
    table2 = summarize_and_test(main_raw[DATASET_NAME], DATASET_NAME)
    save_table(table2, "table2_acc_bwt_fwt")
    checkpoint_save(_STAGE_ID, dict(main_raw=main_raw, baseline_acc_by_dataset=baseline_acc_by_dataset,
                                    curves_raw=curves_raw, table2=table2))

print("\n" + "=" * 78); print("STAGE 1b -- Zero-Trust clean-utility ablation (Table 14)"); print("=" * 78)
_STAGE_ID = "01b_zero_trust_ablation"
if checkpoint_done(_STAGE_ID):
    table14 = checkpoint_load(_STAGE_ID)["table14"]
else:
    rows = []
    for base, zt in ZT_PAIRS:
        ba = np.array([main_raw[DATASET_NAME][base][s]["ACC"] for s in SEEDS_MAIN])
        za = np.array([main_raw[DATASET_NAME][zt][s]["ACC"] for s in SEEDS_MAIN])
        bb = np.array([main_raw[DATASET_NAME][base][s]["BWT"] for s in SEEDS_MAIN])
        zb = np.array([main_raw[DATASET_NAME][zt][s]["BWT"] for s in SEEDS_MAIN])
        try:
            _, p = stats.wilcoxon(ba, za)
        except ValueError:
            p = float("nan")
        pooled = np.sqrt((ba.var(ddof=1) + za.var(ddof=1)) / 2) if len(ba) > 1 else 0
        d = float((za.mean() - ba.mean()) / pooled) if pooled > 0 else float("nan")
        rows.append(dict(Base_method=base, ACC_base=round(float(ba.mean()), 3), ACC_plus_ZT=round(float(za.mean()), 3),
                         ACC_delta=round(float(za.mean() - ba.mean()), 3), BWT_base=round(float(bb.mean()), 3),
                         BWT_plus_ZT=round(float(zb.mean()), 3),
                         p_value_wilcoxon=(round(float(p), 4) if not math.isnan(p) else float("nan")),
                         cohens_d=(round(d, 3) if not math.isnan(d) else float("nan")),
                         clean_utility_cost_of_defense=round(float(ba.mean() - za.mean()), 3),
                         note="Non-adversarial setting; see Table 13 for the adversarial case"))
    table14 = pd.DataFrame(rows)
    save_table(table14, "table14_zero_trust_clean_utility_ablation")
    save_raw(table14, "zero_trust_clean_utility_ablation_raw")
    checkpoint_save(_STAGE_ID, dict(table14=table14))

print("\n" + "=" * 78); print("STAGE 2/9 -- Architecture ablation (Table 3)"); print("=" * 78)

def run_ablation_classifier(model_ctor, tasks, seed, replay_cap=REPLAY_CAP_M):
    torch.manual_seed(seed); np.random.seed(seed)
    model = model_ctor().to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    replay = ExperienceReplay(total_cap=replay_cap)
    for task in tasks:
        x_cur, y_cur = task.x_train, task.y_train
        for _ in range(EPOCHS_PER_DOMAIN):
            x_rep, y_rep = replay.get_replay_batch(replay_cap)
            optimizer.zero_grad()
            loss_cur = F.cross_entropy(model(x_cur), y_cur)
            if x_rep is not None:
                lam_i = x_rep.shape[0] / (x_cur.shape[0] + x_rep.shape[0])
                loss = (1 - lam_i) * loss_cur + lam_i * F.cross_entropy(model(x_rep), y_rep)
            else:
                loss = loss_cur
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=GRAD_CLIP_MAX_NORM)
            optimizer.step()
        replay.update_after_task(x_cur, y_cur, 0)
    return float(np.mean([detection_metrics(model, t.x_test, t.y_test)["accuracy"] for t in tasks]))

_STAGE_ID = "02_architecture_ablation"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID)
    ablation_raw, attn_params, mlp_params, mlp_hidden, table3 = (_c["ablation_raw"], _c["attn_params"],
                                                                  _c["mlp_params"], _c["mlp_hidden"], _c["table3"])
else:
    attn_params = count_params(AttentionTabularClassifier(n_features))
    mlp_hidden = match_mlp_hidden_size(attn_params, n_features, tol=0.05)
    mlp_params = count_params(MLPClassifier(n_features, mlp_hidden))
    print(f"  attention params={attn_params:,}  matched MLP hidden={mlp_hidden} (params={mlp_params:,})")
    AK, MK, XK = "Attention-Transformer (proposed)", "MLP-3-layer (matched params)", "XGBoost (offline, no CL)"
    ablation_raw = {AK: [], MK: [], XK: []}
    for seed in SEEDS_ABLATION:
        ablation_raw[AK].append(cached_unit(f"s2__attn__seed{seed}",
                                lambda: run_ablation_classifier(lambda: AttentionTabularClassifier(n_features), tasks_ds, seed)))
        ablation_raw[MK].append(cached_unit(f"s2__mlp__seed{seed}",
                                lambda: run_ablation_classifier(lambda: MLPClassifier(n_features, mlp_hidden), tasks_ds, seed)))
        print(f"    ablation seed={seed} done (attention/MLP)")
    def _xgb(seed):
        import xgboost as xgb
        x_all = np.concatenate([t.x_train.cpu().numpy() for t in tasks_ds]); y_all = np.concatenate([t.y_train.cpu().numpy() for t in tasks_ds])
        clf = xgb.XGBClassifier(n_estimators=200, max_depth=4, random_state=seed, eval_metric="logloss", verbosity=0)
        clf.fit(x_all, y_all)
        return float(np.mean([accuracy_score(t.y_test.cpu().numpy(), clf.predict(t.x_test.cpu().numpy())) for t in tasks_ds]))
    try:
        for seed in SEEDS_ABLATION:
            ablation_raw[XK].append(cached_unit(f"s2__xgb__seed{seed}", lambda: _xgb(seed)))
    except Exception as e:
        print(f"  WARNING: XGBoost baseline failed ({e}); row left NaN.")
        ablation_raw[XK] = [float("nan")]
    save_raw(dict(ablation_raw=ablation_raw, attn_params=attn_params, mlp_params=mlp_params, mlp_hidden=mlp_hidden),
             "architecture_ablation_raw")
    acc_attn, acc_mlp, acc_xgb = (float(np.mean(ablation_raw[k])) for k in (AK, MK, XK))
    best_noninterp = np.nanmax([acc_mlp, acc_xgb])
    gap_attn = round(acc_attn - best_noninterp, 3)
    table3 = pd.DataFrame([
        {"Classifier": AK, "Params_M": round(attn_params / 1e6, 2), "ACC": round(acc_attn, 3),
         "ACC_std": round(float(np.std(ablation_raw[AK])), 3), "Interpretable": True, "gap_to_best_noninterp": gap_attn,
         "within_1.0pt_threshold": bool((best_noninterp - acc_attn) <= 0.010)},
        {"Classifier": MK, "Params_M": round(mlp_params / 1e6, 2), "ACC": round(acc_mlp, 3),
         "ACC_std": round(float(np.std(ablation_raw[MK])), 3), "Interpretable": False,
         "gap_to_best_noninterp": gap_attn, "within_1.0pt_threshold": None},
        {"Classifier": XK, "Params_M": np.nan, "ACC": round(acc_xgb, 3), "ACC_std": round(float(np.std(ablation_raw[XK])), 3),
         "Interpretable": False, "gap_to_best_noninterp": gap_attn, "within_1.0pt_threshold": None}])
    save_table(table3, "table3_architecture_ablation")
    checkpoint_save(_STAGE_ID, dict(ablation_raw=ablation_raw, attn_params=attn_params, mlp_params=mlp_params,
                                    mlp_hidden=mlp_hidden, table3=table3))

print("\n" + "=" * 78); print("STAGE 3/9 -- Storage footprint (Table 4)"); print("=" * 78)
_STAGE_ID = "03_storage_footprint"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID)
    table4 = _c["table4"]
else:
    vae_params = count_params(VAEGenerator(n_features))
    gan_g_params = count_params(ConditionalGANGenerator(n_features))
    diff_params = count_params(ConditionalDenoiser(n_features))
    BPP = 4
    er_disk_mb = (REPLAY_CAP_M * n_features * BPP) / (1024 ** 2)
    storage_rows = [
        dict(Method="ER (raw buffer)", Storage_type="raw samples", Count_or_params=REPLAY_CAP_M, Disk_MB=round(er_disk_mb, 2)),
        dict(Method="GMR-VAE", Storage_type="generator params", Count_or_params=vae_params, Disk_MB=round(vae_params * BPP / 1024 ** 2, 2)),
        dict(Method="GMR-GAN", Storage_type="generator params (G only)", Count_or_params=gan_g_params, Disk_MB=round(gan_g_params * BPP / 1024 ** 2, 2)),
        dict(Method="GMR-Diffusion", Storage_type="denoiser params", Count_or_params=diff_params, Disk_MB=round(diff_params * BPP / 1024 ** 2, 2))]
    er_mb = storage_rows[0]["Disk_MB"]
    for row in storage_rows:
        row["Edge_target_disk_budget_MB"] = 50
        row["storage_reduction_vs_ER"] = round((er_mb - row["Disk_MB"]) / er_mb, 2) if er_mb else np.nan
        row["deployment_target_note"] = "Representative edge gateway: Raspberry Pi 4-class (1GB RAM, 32GB disk)"
    table4 = pd.DataFrame(storage_rows)
    save_table(table4, "table4_storage_footprint")
    checkpoint_save(_STAGE_ID, dict(table4=table4))

print("\n" + "=" * 78); print("STAGE 4/9 -- Compute cost per generator family (Table 6)"); print("=" * 78)
_STAGE_ID = "04_compute_cost"
if checkpoint_done(_STAGE_ID):
    table6 = checkpoint_load(_STAGE_ID)["table6"]
else:
    def _measure(gen_name, gen_cls):
        t0 = time.time()
        proc = psutil.Process(os.getpid()); rss_before = proc.memory_info().rss
        ens = GenerativeReplayEnsemble(gen_cls, n_features, use_dp=False, gen_epochs=GEN_EPOCHS)
        for t in tasks_ds:
            ens.update_after_task(t.x_train, t.y_train, 0)
        wall_h = (time.time() - t0) / len(tasks_ds) / 3600.0
        t0 = time.time(); _ = ens.get_replay_batch(64); lat = (time.time() - t0) * 1000.0
        ram = max((proc.memory_info().rss - rss_before) / (1024 ** 2), 1.0)
        return dict(Generator=gen_name, GPU_hours_per_domain=round(wall_h, 3), Inference_latency_ms=round(lat, 2),
                    Peak_RAM_MB_ensemble_at_K=round(ram, 1), Disk_MB_ensemble_at_K=round(ens.storage_bytes() / 1024 ** 2, 2),
                    note="Measured wall-clock on the device used (see results/compute_environment.json).")
    compute_rows = []
    for gen_name, gen_cls in [("VAE", VAEGenerator), ("GAN", ConditionalGANGenerator),
                              (f"Diffusion (T={DIFFUSION_T})", DiffusionGenerator)]:
        compute_rows.append(cached_unit(f"s4__{gen_name}", lambda: _measure(gen_name, gen_cls)))
        print(f"  {gen_name}: {compute_rows[-1]}")
    table6 = pd.DataFrame(compute_rows)
    save_table(table6, "table6_compute_cost"); save_raw(compute_rows, "compute_cost_raw")
    import platform
    with open(os.path.join(RESULTS_DIR, "compute_environment.json"), "w", encoding="utf-8") as f:
        json.dump(dict(processor=platform.processor() or platform.machine(), platform=platform.platform(),
                       python_version=platform.python_version(), torch_device_used=str(DEVICE),
                       cuda_available=bool(torch.cuda.is_available()), logical_cpu_count=psutil.cpu_count(logical=True),
                       total_ram_gb=round(psutil.virtual_memory().total / 1024 ** 3, 2), torch_version=torch.__version__), f, indent=2)
    checkpoint_save(_STAGE_ID, dict(table6=table6))

print("\n" + "=" * 78); print("STAGE 5/9 -- Privacy-utility-forgetting sweep (Tables 7/8/9/9b/13)"); print("=" * 78)

# ---- 5a ----
_STAGE_ID = "05a_privacy_sweep"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID); privacy_raw, table7 = _c["privacy_raw"], _c["table7"]
else:
    privacy_raw = {}
    for gen_method in GENERATIVE_LIST:
        privacy_raw[gen_method] = {}
        for eps_star in DP_TARGET_EPSILONS + [None]:
            eps_label = "inf (non-DP)" if eps_star is None else str(eps_star)
            privacy_raw[gen_method][eps_label] = {}
            for seed in SEEDS_PRIVACY:
                def _run():
                    res = run_domain_incremental(gen_method, tasks_ds, seed, dp_eps_star=eps_star)
                    mia = classifier_mia_advantage(res["model"], res["x_members"], res["y_members"],
                                                   res["x_nonmembers"], res["y_nonmembers"], seed=seed)
                    return dict(ACC=res["ACC"], BWT=res["BWT"], mia_adv=mia)
                u = cached_unit(f"s5a__{gen_method}__eps{eps_label}__seed{seed}", _run)
                privacy_raw[gen_method][eps_label][seed] = u
                print(f"    {gen_method:18s} eps*={eps_label:12s} seed={seed} ACC={u['ACC']:.3f} BWT={u['BWT']:.3f} MIA={u['mia_adv']:.3f}")
                gc.collect()
    save_raw(privacy_raw, "privacy_sweep_raw")
    rows = []
    for gen_method in GENERATIVE_LIST:
        for eps_star in DP_TARGET_EPSILONS + [None]:
            d = privacy_raw[gen_method]["inf (non-DP)" if eps_star is None else str(eps_star)]
            rows.append(dict(Generator=gen_method, epsilon_star=("inf (non-DP)" if eps_star is None else eps_star),
                             ACC=round(float(np.mean([v["ACC"] for v in d.values()])), 3),
                             BWT=round(float(np.mean([v["BWT"] for v in d.values()])), 3),
                             classifier_pathway_MIA_advantage=round(float(np.mean([v["mia_adv"] for v in d.values()])), 3),
                             note="classifier_pathway_MIA_advantage carries NO formal DP bound (see Table 9)"))
    table7 = pd.DataFrame(rows)
    save_table(table7, "table7_privacy_utility_forgetting_tradeoff")
    checkpoint_save(_STAGE_ID, dict(privacy_raw=privacy_raw, table7=table7))

# ---- 5b ----
_STAGE_ID = "05b_dp_er_baseline"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID); dper_raw, nondp_er_acc, table8 = _c["dper_raw"], _c["nondp_er_acc"], _c["table8"]
else:
    nondp_er_acc = [cached_unit(f"s5b__ER_nonDP__seed{s}", lambda: run_domain_incremental("ER", tasks_ds, s)["ACC"])
                    for s in SEEDS_PRIVACY]
    dper_raw = {}
    for eps_star in DP_TARGET_EPSILONS:
        dper_raw[eps_star] = {}
        for seed in SEEDS_PRIVACY:
            dper_raw[eps_star][seed] = cached_unit(
                f"s5b__DP-ER__eps{eps_star}__seed{seed}",
                lambda: run_domain_incremental("DP-ER", tasks_ds, seed, dp_eps_star=eps_star)["ACC"])
    save_raw(dict(dper_raw=dper_raw, nondp_er_acc=nondp_er_acc), "dp_er_baseline_raw")
    rows = []
    for eps_star in DP_TARGET_EPSILONS:
        dp_gmr = np.mean([v["ACC"] for v in privacy_raw["GMR-GAN"][str(eps_star)].values()])
        dp_zt = np.mean([v["ACC"] for v in privacy_raw["GMR-GAN-ZT"][str(eps_star)].values()])
        dp_er = np.mean(list(dper_raw[eps_star].values()))
        nd = float(np.mean(nondp_er_acc))
        rows.append(dict(epsilon_star=eps_star, **{"DP-GMR_ACC": round(float(dp_gmr), 3), "DP-GMR-ZT_ACC": round(float(dp_zt), 3),
                         "DP-ER_ACC": round(float(dp_er), 3), "NonDP-ER_ACC": round(nd, 3),
                         "gain_generative_vs_naive_noising": round(float(dp_gmr - dp_er), 3),
                         "gain_zt_vs_plain_gmr": round(float(dp_zt - dp_gmr), 3),
                         "gain_zt_vs_naive_noising": round(float(dp_zt - dp_er), 3),
                         "cost_of_privacy_vs_nondp": round(float(nd - dp_gmr), 3)}))
    table8 = pd.DataFrame(rows)
    save_table(table8, "table8_dpgmr_vs_dper_vs_nondp")
    checkpoint_save(_STAGE_ID, dict(dper_raw=dper_raw, nondp_er_acc=nondp_er_acc, table8=table8))

# ---- 5c ----
_STAGE_ID = "05c_classifier_mia_exposure"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID); mia_ref, table9 = _c["mia_ref"], _c["table9"]
else:
    def _mia_ref():
        r = run_domain_incremental("ER", tasks_ds, seed=SEEDS_PRIVACY[0])
        return classifier_mia_advantage(r["model"], r["x_members"], r["y_members"], r["x_nonmembers"], r["y_nonmembers"])
    mia_ref = cached_unit("s5c__mia_ref", _mia_ref)
    table9 = pd.DataFrame([dict(Pathway="Classifier (f_theta, raw current-domain SGD)",
                                empirical_MIA_advantage=round(mia_ref, 3),
                                formal_DP_bound="none (explicitly out of scope, Design Goal iii)",
                                interpretation="Undefended: adversary attacking f_theta directly bypasses generator DP certificate")])
    save_table(table9, "table9_classifier_pathway_mia_exposure")
    checkpoint_save(_STAGE_ID, dict(mia_ref=mia_ref, table9=table9))

# ---- 5d ----
_STAGE_ID = "05d_dpsgd_classifier_ablation"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID)
    dpsgd_classifier_raw, nondp_classifier_acc_mean, table9b = _c["dpsgd_classifier_raw"], _c["nondp_classifier_acc_mean"], _c["table9b"]
else:
    def train_classifier_dp(tasks, eps_star, seed, epochs_per_domain=EPOCHS_PER_DOMAIN):
        torch.manual_seed(seed); np.random.seed(seed)
        model = AttentionTabularClassifier(tasks[0].n_features).to(DEVICE)
        optimizer = torch.optim.Adam(model.parameters(), lr=LR)
        accountant = RDPPrivacyAccountant()
        noise_mult = calibrate_noise_multiplier(eps_star, DP_SAMPLE_RATE, epochs_per_domain * len(tasks), DP_DELTA)
        rng = np.random.RandomState(seed)
        for task in tasks:
            for _ in range(epochs_per_domain):
                dp_sgd_classifier_step(model, optimizer, task.x_train, task.y_train, DP_CLIP_NORM,
                                       noise_mult, DP_SAMPLE_RATE, accountant, rng)
        acc = float(np.mean([detection_metrics(model, t.x_test, t.y_test)["accuracy"] for t in tasks]))
        mia = classifier_mia_advantage(model, torch.cat([t.x_train for t in tasks]), torch.cat([t.y_train for t in tasks]),
                                       torch.cat([t.x_test for t in tasks]), torch.cat([t.y_test for t in tasks]), seed=seed)
        return dict(acc=acc, mia=mia)
    nondp_classifier_acc_mean = float(np.mean(nondp_er_acc[:2]))
    dpsgd_classifier_raw, rows = {}, []
    for eps_star in [3, 8]:
        outs = [cached_unit(f"s5d__dpsgd__eps{eps_star}__seed{s}", lambda: train_classifier_dp(tasks_ds, eps_star, s))
                for s in SEEDS_PRIVACY[:2]]
        accs, mias = [o["acc"] for o in outs], [o["mia"] for o in outs]
        dpsgd_classifier_raw[eps_star] = dict(accs=accs, mias=mias)
        dp_acc = float(np.mean(accs))
        rows.append(dict(epsilon_star=eps_star, NonDP_classifier_ACC=round(nondp_classifier_acc_mean, 3),
                         DPSGD_classifier_ACC=round(dp_acc, 3),
                         ACC_point_cost=round((nondp_classifier_acc_mean - dp_acc) * 100, 2),
                         classifier_MIA_advantage_after_DPSGD=round(float(np.mean(mias)), 3),
                         literature_reference_range_pts="2-6 (Mironov et al., comparable tabular transformers)",
                         note="Small-scale preliminary ablation"))
    table9b = pd.DataFrame(rows)
    save_table(table9b, "table9b_dpsgd_classifier_ablation")
    save_raw(dict(dpsgd_classifier_raw=dpsgd_classifier_raw, nondp_classifier_acc_mean=nondp_classifier_acc_mean,
                  mia_ref=mia_ref), "privacy_ablations_raw")
    checkpoint_save(_STAGE_ID, dict(dpsgd_classifier_raw=dpsgd_classifier_raw,
                                    nondp_classifier_acc_mean=nondp_classifier_acc_mean, table9b=table9b))

# ---- 5e ----
_STAGE_ID = "05e_zero_trust_robustness"
POISON_RATES = [0.0, 0.1, 0.3, 0.5]
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID); zt_robustness_raw, table13 = _c["zt_robustness_raw"], _c["table13"]
else:
    zt_robustness_raw = {}
    for base, zt in ZT_PAIRS:
        for method_name in (base, zt):
            zt_robustness_raw[method_name] = {}
            for p in POISON_RATES:
                zt_robustness_raw[method_name][p] = {}
                for seed in SEEDS_PRIVACY:
                    res = cached_unit(f"s5e__{method_name}__p{p:.1f}__seed{seed}",
                                      lambda: run_zero_trust_robustness_trial(method_name, tasks_ds, seed, poison_rate=p))
                    zt_robustness_raw[method_name][p][seed] = res
                    print(f"    {method_name:18s} poison={p:.1f} seed={seed} ACC={res['ACC']:.3f} BWT={res['BWT']:.3f} rej={res['poisoned_rejection_rate']}")
    save_raw(zt_robustness_raw, "zero_trust_robustness_raw")
    rows = []
    for base, zt in ZT_PAIRS:
        for method_name in (base, zt):
            for p in POISON_RATES:
                sd = zt_robustness_raw[method_name][p]
                accs = [v["ACC"] for v in sd.values()]; bwts = [v["BWT"] for v in sd.values()]
                rej = [v["poisoned_rejection_rate"] for v in sd.values() if not math.isnan(v["poisoned_rejection_rate"])]
                rows.append(dict(Base_family=base, Method=method_name, poison_rate=p,
                                 ACC_mean=round(float(np.mean(accs)), 3), ACC_std=round(float(np.std(accs)), 3),
                                 BWT_mean=round(float(np.mean(bwts)), 3), BWT_std=round(float(np.std(bwts)), 3),
                                 poisoned_sample_rejection_rate=(round(float(np.mean(rej)), 3) if rej else float("nan")),
                                 note="rejection_rate is NaN for plain (non-ZT) baseline: no verification layer"))
    table13 = pd.DataFrame(rows)
    save_table(table13, "table13_zero_trust_adversarial_robustness")
    checkpoint_save(_STAGE_ID, dict(zt_robustness_raw=zt_robustness_raw, table13=table13))

print("\n" + "=" * 78); print("STAGE 6/9 -- Flow-key composition audit (Table 10)"); print("=" * 78)
_STAGE_ID = "06_composition_audit"
if checkpoint_done(_STAGE_ID):
    table10 = checkpoint_load(_STAGE_ID)["table10"]
else:
    table10 = flow_key_composition_audit(tasks_ds)
    save_table(table10, "table10_composition_audit"); save_raw(table10, "composition_audit_raw")
    checkpoint_save(_STAGE_ID, dict(table10=table10))

print("\n" + "=" * 78); print("STAGE 7/9 -- SI equivalence check (Table 12)"); print("=" * 78)
_STAGE_ID = "07_si_equivalence"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID); si_log_df, table12 = _c["si_log_df"], _c["table12"]
else:
    logs = []
    for dn in DATASETS:
        for seed in SEEDS_MAIN:
            for entry in (main_raw[dn]["SI"][seed]["si_equivalence"] or []):
                logs.append(dict(dataset=dn, seed=seed, **entry))
    si_log_df = pd.DataFrame(logs)
    save_raw(si_log_df, "si_equivalence_raw")
    if not si_log_df.empty:
        table12 = si_log_df.groupby("domain_boundary")[["mean_relative_deviation", "max_relative_deviation"]].mean().reset_index()
        table12["mean_relative_deviation"] = table12["mean_relative_deviation"].round(5)
        table12["max_relative_deviation"] = table12["max_relative_deviation"].round(5)
    else:
        table12 = pd.DataFrame(columns=["domain_boundary", "mean_relative_deviation", "max_relative_deviation"])
    save_table(table12, "table12_si_equivalence_check")
    checkpoint_save(_STAGE_ID, dict(si_log_df=si_log_df, table12=table12))

print("\n" + "=" * 78); print("STAGE 8/9 -- Explainability (Table 11) + attribution baselines"); print("=" * 78)
_STAGE_ID = "08_explainability"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID)
    faithfulness_raw = _c["faithfulness_raw"]
    final_models = {k: _model_from_checkpoint(v, DEVICE) for k, v in _c["final_models_state"].items()}
    table11, attribution_baseline_raw, p_ag_vs_ig = _c["table11"], _c["attribution_baseline_raw"], _c["p_ag_vs_ig"]
else:
    faithfulness_raw, final_models, model_states = {}, {}, {}
    for dataset_name, tasks in DATASETS.items():
        st = cached_unit(f"s8__model__{dataset_name}",
                         lambda: _model_state_for_checkpoint(run_domain_incremental(PROPOSED_METHOD, tasks, seed=SEEDS_MAIN[0])["model"]))
        model_states[dataset_name] = st
        final_models[dataset_name] = _model_from_checkpoint(st, DEVICE)
        df_faith = cached_unit(f"s8__faith__{dataset_name}",
                               lambda: evaluate_faithfulness_per_domain(final_models[dataset_name], tasks, K=len(tasks), n_probes=32, seed=SEEDS_MAIN[0]))
        df_faith = df_faith.copy(); df_faith.insert(0, "Dataset", dataset_name)
        faithfulness_raw[dataset_name] = df_faith
    save_raw(faithfulness_raw, "faithfulness_raw")
    table11 = pd.concat(list(faithfulness_raw.values()), ignore_index=True)
    table11 = table11[["Dataset", "Domain", "domains_elapsed_since_trained", "deletion_AUC_method", "deletion_AUC_random",
                       "insertion_AUC_method", "insertion_AUC_random", "note"]]
    save_table(table11, "table11_faithfulness_auc_per_domain")

    def _attr_baseline():
        out = {"AttnxGrad": [], "IG": [], "Random": []}
        model = final_models[DATASET_NAME]
        rng = np.random.RandomState(SEEDS_MAIN[0])
        for task in tasks_ds:
            y_np = task.y_test.cpu().numpy()
            benign = y_np == 0
            ref = task.x_test[benign].median(dim=0).values if benign.any() else task.x_test.median(dim=0).values
            attack_idx = np.where(y_np == 1)[0]
            if len(attack_idx) == 0:
                continue
            for idx in rng.choice(attack_idx, size=min(4, len(attack_idx)), replace=False):
                xs = task.x_test[idx:idx + 1]
                o_ag = np.argsort(-attention_gradient_importance(model, xs, target_class=1))
                o_ig = np.argsort(-integrated_gradients_importance(model, xs, ref.unsqueeze(0), target_class=1))
                o_r = rng.permutation(task.n_features)
                out["AttnxGrad"].append(_trapz_auc(deletion_insertion_curve(model, xs, o_ag, ref)[0]))
                out["IG"].append(_trapz_auc(deletion_insertion_curve(model, xs, o_ig, ref)[0]))
                out["Random"].append(_trapz_auc(deletion_insertion_curve(model, xs, o_r, ref)[0]))
        return out
    attribution_baseline_raw = cached_unit("s8__attribution", _attr_baseline)
    save_raw(attribution_baseline_raw, "attribution_baseline_raw")
    try:
        _, p_ag_vs_ig = stats.wilcoxon(attribution_baseline_raw["AttnxGrad"], attribution_baseline_raw["IG"])
    except ValueError:
        p_ag_vs_ig = float("nan")
    print(f"  Attn x Grad vs IG (deletion AUC), paired Wilcoxon p={p_ag_vs_ig:.4f}")
    checkpoint_save(_STAGE_ID, dict(faithfulness_raw=faithfulness_raw, final_models_state=model_states, table11=table11,
                                    attribution_baseline_raw=attribution_baseline_raw, p_ag_vs_ig=float(p_ag_vs_ig)))

print("\n" + "=" * 78); print("STAGE 9/9 -- RDP trace + replay-cap sweep"); print("=" * 78)
_STAGE_ID = "09_rdp_trace_and_replay_cap"
if checkpoint_done(_STAGE_ID):
    _c = checkpoint_load(_STAGE_ID); rdp_trace_raw, replay_cap_raw = _c["rdp_trace_raw"], _c["replay_cap_raw"]
else:
    def _trace(eps_star):
        steps_total = GEN_EPOCHS * K_DOMAINS
        nm = calibrate_noise_multiplier(eps_star, DP_SAMPLE_RATE, steps_total, DP_DELTA)
        acc, tr, every = RDPPrivacyAccountant(), [], max(1, steps_total // 40)
        for step in range(1, steps_total + 1):
            acc.step(noise_multiplier=nm, sample_rate=DP_SAMPLE_RATE)
            if step % every == 0 or step == steps_total:
                tr.append((step, acc.get_epsilon()))
        return tr
    rdp_trace_raw = {e: cached_unit(f"s9__rdp__eps{e}", lambda: _trace(e)) for e in DP_TARGET_EPSILONS}
    save_raw(rdp_trace_raw, "rdp_composition_trace_raw")
    replay_cap_raw = {}
    for M in [250, 1000, 2000, 4000, 8000]:
        outs = [cached_unit(f"s9__cap{M}__seed{s}",
                            lambda: (lambda r: dict(ACC=r["ACC"], BWT=r["BWT"]))(run_domain_incremental("GMR-GAN", tasks_ds, s, replay_cap=M)))
                for s in SEEDS_PRIVACY[:2]]
        replay_cap_raw[M] = dict(ACC=float(np.mean([o["ACC"] for o in outs])), BWT=float(np.mean([o["BWT"] for o in outs])))
        print(f"    M={M}: ACC={replay_cap_raw[M]['ACC']:.3f} BWT={replay_cap_raw[M]['BWT']:.3f}")
    save_raw(replay_cap_raw, "replay_cap_sensitivity_raw")
    checkpoint_save(_STAGE_ID, dict(rdp_trace_raw=rdp_trace_raw, replay_cap_raw=replay_cap_raw))

# ==============================================================================
# FIGURES
# ==============================================================================
apply_plot_style()
print("\n" + "=" * 78); print("Building Figures 1-7"); print("=" * 78)
_STAGE_ID = "10_figures"
if checkpoint_done(_STAGE_ID):
    print("  [checkpoint] figures already saved locally, skipping")
else:
    DS = DATASET_NAME
    # ---- Figure 1
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9), constrained_layout=True)
    ax = axes[0]
    for method in METHOD_ORDER:
        trajs = []
        for seed in SEEDS_MAIN:
            R = np.array(main_raw[DS][method][seed]["R"]); K = R.shape[0]
            trajs.append([0.0 if t == 0 else float(np.mean([R[t, j] - R[j, j] for j in range(t)])) for t in range(K)])
        mt = np.mean(trajs, axis=0)
        ax.plot(range(1, len(mt) + 1), mt, marker="o", markersize=2.5, linewidth=1.3, color=PALETTE[method], label=method, alpha=0.9)
    style_axes(ax); ax.axhline(0, color=SUBTEXT_COLOR, linewidth=0.8, linestyle="--", alpha=0.6)
    ax.set_xlabel("Domains elapsed", fontsize=7.5); ax.set_ylabel("BWT", fontsize=7.5)
    panel_letter(ax, "A", "BWT trajectory across domains"); legend_above(ax, ncol=6, fontsize=5.2)
    ax = axes[1]
    pr = table2[~table2["proposed_method"]].sort_values("cohens_d_vs_proposed")
    y_pos = np.arange(len(pr)); d_vals = pr["cohens_d_vs_proposed"].fillna(0).values
    se_d = np.abs(d_vals) / max(np.sqrt(len(SEEDS_MAIN)), 1)
    sig = pr["significant_at_0.05"].apply(lambda v: bool(v) if pd.notna(v) else False).values
    cols_sig = [PALETTE["GMR-GAN"] if s else PALETTE["control"] for s in sig]
    ax.hlines(y_pos, d_vals - 1.96 * se_d, d_vals + 1.96 * se_d, color=cols_sig, linewidth=1.6, alpha=0.85)
    ax.scatter(d_vals, y_pos, color=cols_sig, s=32, zorder=5, edgecolor="white", linewidth=0.5)
    for xv, ls in ((0, "--"), (0.5, ":"), (-0.5, ":")):
        ax.axvline(xv, color=SUBTEXT_COLOR, linestyle=ls, linewidth=0.8, alpha=0.7)
    ax.set_yticks(y_pos); ax.set_yticklabels(pr["Method"], fontsize=6.5); style_axes(ax)
    ax.set_xlabel(f"Cohen's d vs. proposed ({PROPOSED_METHOD})", fontsize=7.5)
    panel_letter(ax, "B", "Effect size vs. proposed method")
    le = [Line2D([0], [0], marker="o", color=PALETTE["GMR-GAN"], linestyle="", markersize=5, label="Significant (Holm-Bonferroni)"),
          Line2D([0], [0], marker="o", color=PALETTE["control"], linestyle="", markersize=5, label="Not significant")]
    legend_above(ax, ncol=2, fontsize=5.8, handles=le, labels=[h.get_label() for h in le])
    save_figure(fig, "figure1_cl_performance_summary", "Figure 1. Continual-learning performance summary on TON_IoT.")

    # ---- Figure 2
    n_cols2, n_rows2 = 5, int(np.ceil(K_DOMAINS / 5))
    fig, axes = plt.subplots(n_rows2, n_cols2, figsize=(7.0, 3.0), sharex=True, sharey=True, constrained_layout=True, squeeze=False)
    af = axes.flatten(); href, lref = None, None
    for d_idx in range(K_DOMAINS):
        ax = af[d_idx]; dn = tasks_ds[d_idx].name
        for method in CURVE_METHODS:
            sc = [curves_raw[DS][method][s][dn] for s in SEEDS_MAIN if dn in curves_raw[DS][method][s]]
            if not sc: continue
            arr = np.array(sc); m, s_ = arr.mean(0), arr.std(0); ex = np.arange(1, arr.shape[1] + 1)
            ax.plot(ex, m, color=PALETTE[method], linewidth=1.1, label=method)
            ax.fill_between(ex, m - s_, m + s_, color=PALETTE[method], alpha=0.18, linewidth=0)
        style_axes(ax); ax.set_title(f"D{d_idx + 1}", fontsize=7, color=SUBTEXT_COLOR, loc="center", fontweight="normal", pad=2)
        ax.tick_params(labelsize=6)
        if d_idx == 0: href, lref = ax.get_legend_handles_labels()
    for extra in range(K_DOMAINS, len(af)): af[extra].axis("off")
    fig.supxlabel("Epoch (within current-domain training)", fontsize=7.5, color=SUBTEXT_COLOR)
    fig.supylabel("Val. accuracy", fontsize=7.5, color=SUBTEXT_COLOR)
    legend_above(fig, ncol=4, fontsize=6.5, handles=href, labels=lref)
    save_figure(fig, "figure2_learning_curves_per_domain", "Figure 2. Per-domain learning curves.")

    # ---- Figure 3
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.6), constrained_layout=True)
    gens3 = ["GMR-VAE", "GMR-VAE-ZT", "GMR-GAN", "GMR-GAN-ZT", "GMR-Diffusion", "GMR-Diffusion-ZT"]
    EV = DP_TARGET_EPSILONS
    def _series(gen, key): return [np.mean([v[key] for v in privacy_raw[gen][str(e)].values()]) for e in EV]
    ax = axes[0, 0]; lines_a = []
    for gen in gens3:
        l, = ax.plot(EV, _series(gen, "ACC"), marker="o", markersize=3, linewidth=1.3,
                     linestyle="--" if gen.endswith(ZT_SUFFIX) else "-", color=PALETTE[gen], label=gen)
        lines_a.append(l)
    style_axes(ax); ax.set_xlabel(r"$\epsilon^*$", fontsize=7.5); ax.set_ylabel("ACC", fontsize=7.5)
    panel_letter(ax, "A", "Utility vs. privacy budget"); legend_above(fig, ncol=6, fontsize=5.2, handles=lines_a, labels=gens3)
    ax = axes[0, 1]
    for gen in gens3:
        ax.plot(EV, _series(gen, "BWT"), marker="^", markersize=3.2, linewidth=1.3,
                linestyle="--" if gen.endswith(ZT_SUFFIX) else "-", color=PALETTE[gen])
    style_axes(ax); ax.set_xlabel(r"$\epsilon^*$", fontsize=7.5); ax.set_ylabel("BWT", fontsize=7.5)
    panel_letter(ax, "B", "Forgetting vs. privacy budget")
    ax = axes[0, 2]
    for gen in gens3:
        ax.plot(EV, _series(gen, "mia_adv"), marker="s", markersize=3, linewidth=1.3,
                linestyle="--" if gen.endswith(ZT_SUFFIX) else "-", color=PALETTE[gen], alpha=0.9)
    style_axes(ax); ax.set_xlabel(r"$\epsilon^*$", fontsize=7.5); ax.set_ylabel("Classifier MIA adv.", fontsize=7)
    panel_letter(ax, "C", "Residual classifier exposure")
    ax = axes[1, 0]
    tb = [math.tanh(e / 2) for e in EV]
    ax.plot(EV, tb, linewidth=1.4, color=PALETTE["GMR-Diffusion"], marker="s", markersize=3.5, label=r"tanh($\epsilon^*$/2) bound")
    ax.plot(EV, _series("GMR-GAN", "mia_adv"), linewidth=1.4, color=PALETTE["GMR-GAN"], marker="o", markersize=3.5,
            label="Empirical (classifier-pathway proxy)")
    ax.fill_between(EV, 0, tb, color=PALETTE["GMR-Diffusion"], alpha=0.08)
    style_axes(ax); ax.set_xlabel(r"$\epsilon^*$", fontsize=7.5); ax.set_ylabel("MIA advantage", fontsize=7.5)
    panel_letter(ax, "D", "Generator-pathway sanity check"); legend_above(ax, ncol=1, fontsize=5.6)
    ax = axes[1, 1]
    x = np.arange(len(EV)); w = 0.2
    ax.bar(x - 1.5 * w, table8["DP-GMR_ACC"], width=w, color=PALETTE["GMR-GAN"], label="DP-GMR (GAN)")
    ax.bar(x - 0.5 * w, table8["DP-GMR-ZT_ACC"], width=w, color=PALETTE["GMR-GAN-ZT"], label="DP-GMR-ZT")
    ax.bar(x + 0.5 * w, table8["DP-ER_ACC"], width=w, color=PALETTE["DP-ER"], label="DP-ER")
    ax.bar(x + 1.5 * w, table8["NonDP-ER_ACC"], width=w, color=PALETTE["NonDP-ER"], label="Non-DP ER")
    ax.set_xticks(x); ax.set_xticklabels([str(v) for v in EV], fontsize=6.5); style_axes(ax)
    ax.set_xlabel(r"$\epsilon^*$", fontsize=7.5); ax.set_ylabel("ACC", fontsize=7.5)
    panel_letter(ax, "E", "Generative vs. naive noising"); legend_above(ax, ncol=4, fontsize=5.0)
    ax = axes[1, 2]
    for e in EV:
        ax.plot([s for s, _ in rdp_trace_raw[e]], [v for _, v in rdp_trace_raw[e]], linewidth=1.3, label=fr"$\epsilon^*$={e}")
    style_axes(ax); ax.set_xlabel("Training step", fontsize=7); ax.set_ylabel(r"Cumulative $\epsilon$", fontsize=7.5)
    ax.tick_params(labelsize=6); panel_letter(ax, "F", "Budget accumulation (RDP)"); legend_above(ax, ncol=3, fontsize=5.8)
    save_figure(fig, "figure3_privacy_dashboard", "Figure 3. Privacy dashboard.")

    # ---- Figure 4
    fig, axes = plt.subplots(2, 2, figsize=(6.6, 5.4), constrained_layout=True)
    ax = axes[0, 0]
    dd = tasks_ds[-1]; y_np = dd.y_test.cpu().numpy(); benign = y_np == 0
    ref = dd.x_test[benign].median(dim=0).values if benign.any() else dd.x_test.median(dim=0).values
    xs = dd.x_test[np.where(y_np == 1)[0][0]:np.where(y_np == 1)[0][0] + 1]
    fm = final_models[DS]
    real_order = np.argsort(-attention_gradient_importance(fm, xs, target_class=1))
    rand_order = np.random.RandomState(0).permutation(dd.n_features)
    d_real, i_real = deletion_insertion_curve(fm, xs, real_order, ref)
    d_rand, i_rand = deletion_insertion_curve(fm, xs, rand_order, ref)
    fr = np.linspace(0, 1, len(d_real))
    ax.plot(fr, d_real, color=PALETTE["GMR-GAN"], linewidth=1.4, marker="o", markersize=2.5, label="Deletion - Attn x Grad")
    ax.plot(fr, d_rand, color=PALETTE["control"], linewidth=1.2, linestyle="--", marker="o", markersize=2.5, label="Deletion - random")
    ax.plot(fr, i_real, color=PALETTE["GMR-Diffusion"], linewidth=1.4, marker="s", markersize=2.5, label="Insertion - Attn x Grad")
    ax.plot(fr, i_rand, color=PALETTE["SI"], linewidth=1.2, linestyle="--", marker="s", markersize=2.5, label="Insertion - random")
    style_axes(ax); ax.set_xlabel("Fraction removed/restored", fontsize=7); ax.set_ylabel("Attack prob. p(x)", fontsize=7.5)
    panel_letter(ax, "A", "Deletion/insertion curves"); legend_above(ax, ncol=2, fontsize=5.4)
    ax = axes[0, 1]
    ks = ["AttnxGrad", "IG", "Random"]
    means = [np.mean(attribution_baseline_raw[k]) for k in ks]; stds = [np.std(attribution_baseline_raw[k]) for k in ks]
    ax.bar(["Attn x Grad", "IG", "Random"], means, yerr=stds, capsize=3,
           color=[PALETTE["GMR-GAN"], PALETTE["IG"], PALETTE["control"]], error_kw={"linewidth": 0.8})
    style_axes(ax); ax.set_ylabel("Deletion AUC (lower=better)", fontsize=7); panel_letter(ax, "B", "Attribution baseline comparison")
    y_top = max(means[0], means[1]) + max(stds[0], stds[1]) + 0.04
    ax.plot([0, 1], [y_top, y_top], color=TEXT_COLOR, linewidth=0.7)
    star = "*" if (not math.isnan(p_ag_vs_ig) and p_ag_vs_ig < 0.05) else "n.s."
    ax.text(0.5, y_top + 0.01, f"{star} (p={p_ag_vs_ig:.3f})", ha="center", fontsize=5.8, color=TEXT_COLOR)
    ax = axes[1, 0]
    df = faithfulness_raw[DS].sort_values("domains_elapsed_since_trained")
    ax.scatter(df["domains_elapsed_since_trained"], df["deletion_AUC_method"], color=PALETTE["GMR-GAN"], s=18, alpha=0.85, label="Deletion AUC")
    ax.scatter(df["domains_elapsed_since_trained"], df["insertion_AUC_method"], color=PALETTE["GMR-Diffusion"], s=18, alpha=0.85, marker="s", label="Insertion AUC")
    if len(df) > 1:
        xs_ = np.linspace(0, df["domains_elapsed_since_trained"].max(), 20)
        for col, c in (("deletion_AUC_method", PALETTE["GMR-GAN"]), ("insertion_AUC_method", PALETTE["GMR-Diffusion"])):
            ax.plot(xs_, np.polyval(np.polyfit(df["domains_elapsed_since_trained"], df[col], 1), xs_), color=c, linewidth=1.0, alpha=0.6)
    style_axes(ax); ax.set_xlabel("Domains since last trained", fontsize=6.8); ax.set_ylabel("Faithfulness AUC", fontsize=7)
    panel_letter(ax, "C", "Faithfulness vs. recency")
    ax.text(0.98, 0.04, DS, transform=ax.transAxes, ha="right", va="bottom", fontsize=6, color=SUBTEXT_COLOR, style="italic")
    hc, lc = ax.get_legend_handles_labels(); legend_above(fig, ncol=2, fontsize=6, handles=hc, labels=lc)
    axes[1, 1].axis("off")
    save_figure(fig, "figure4_explainability_dashboard", "Figure 4. Explainability dashboard.")

    # ---- Figure 5
    fig, axes = plt.subplots(2, 3, figsize=(7.0, 4.4), constrained_layout=True)
    ax = axes[0, 0]
    accs_, stds_ = table3["ACC"].tolist(), table3["ACC_std"].tolist()
    ax.bar(np.arange(3), accs_, yerr=stds_, capsize=2, color=[PALETTE["GMR-GAN"], PALETTE["control"], PALETTE["control"]], error_kw={"linewidth": 0.8})
    ax.axhline(accs_[0] - 0.010, color=SUBTEXT_COLOR, linestyle=":", linewidth=0.8)
    ax.set_xticks(np.arange(3)); ax.set_xticklabels(["Attention\n(proposed)", "MLP-3L", "XGBoost"], fontsize=6)
    style_axes(ax); ax.set_ylabel("ACC", fontsize=7.5); panel_letter(ax, "A", "Architecture ablation")
    ax.text(0.98, 0.03, "dotted: 1.0-pt\nthreshold", transform=ax.transAxes, ha="right", va="bottom", fontsize=5, color=SUBTEXT_COLOR)
    ax = axes[0, 1]
    gens_ = table6["Generator"].tolist(); x = np.arange(len(gens_)); ax2b = ax.twinx()
    b1 = ax.bar(x - 0.18, table6["GPU_hours_per_domain"], width=0.36, color=PALETTE["GMR-VAE"])
    b2 = ax2b.bar(x + 0.18, table6["Inference_latency_ms"], width=0.36, color=PALETTE["GMR-Diffusion"])
    ax.set_xticks(x); ax.set_xticklabels([g.split(" ")[0] for g in gens_], fontsize=6.5); style_axes(ax)
    ax.set_ylabel("Hours/domain", fontsize=6.8); ax2b.set_ylabel("Latency (ms)", fontsize=6.8, color=PALETTE["GMR-Diffusion"])
    ax2b.tick_params(labelsize=6, colors=PALETTE["GMR-Diffusion"]); ax2b.grid(False)
    panel_letter(ax, "B", "Compute cost per generator"); legend_above(ax, ncol=2, fontsize=5.6, handles=[b1, b2], labels=["Hours/domain", "Latency (ms)"])
    ax = axes[0, 2]
    mat = np.zeros((K_DOMAINS, K_DOMAINS))
    for _, r in table10.iterrows():
        mat[int(r["domain_i"]) - 1, int(r["domain_j"]) - 1] = 1 if r["status"] == "sequential" else 0
    ax.imshow(np.where(np.triu(np.ones_like(mat, dtype=bool), k=0), np.nan, mat), cmap="Greens", vmin=0, vmax=1, aspect="auto")
    ax.set_xticks(range(K_DOMAINS)); ax.set_yticks(range(K_DOMAINS))
    ax.set_xticklabels(range(1, K_DOMAINS + 1), fontsize=5); ax.set_yticklabels(range(1, K_DOMAINS + 1), fontsize=5)
    ax.set_xlabel("Domain j", fontsize=6.8); ax.set_ylabel("Domain i", fontsize=6.8); ax.grid(False)
    for sp in ax.spines.values(): sp.set_visible(False)
    panel_letter(ax, "C", "Composition audit")
    le = [Patch(facecolor="#EDF8F0", edgecolor="#4D4D4D", linewidth=0.5, label="Disjoint-confirmed"),
          Patch(facecolor="#238B45", edgecolor="#4D4D4D", linewidth=0.5, label="Sequential (overlap)")]
    legend_above(ax, ncol=2, fontsize=5.4, handles=le, labels=[h.get_label() for h in le])
    ax = axes[1, 0]
    if not table12.empty:
        ax.bar(table12["domain_boundary"], table12["mean_relative_deviation"], color=PALETTE["SI"], width=0.6, label="Mean rel. deviation")
        ax.scatter(table12["domain_boundary"], table12["max_relative_deviation"], color=TEXT_COLOR, s=10, zorder=5, marker="_", label="Max rel. deviation")
    style_axes(ax); ax.set_xlabel("Domain boundary", fontsize=7); ax.set_ylabel("Relative deviation", fontsize=6.8)
    panel_letter(ax, "D", "SI equivalence check"); legend_above(ax, ncol=2, fontsize=5.4)
    ax = axes[1, 1]
    Mv = sorted(replay_cap_raw.keys()); ax2e = ax.twinx()
    l1, = ax.plot(Mv, [replay_cap_raw[m]["ACC"] for m in Mv], marker="o", markersize=3, color=PALETTE["GMR-GAN"], linewidth=1.3)
    l2, = ax2e.plot(Mv, [replay_cap_raw[m]["BWT"] for m in Mv], marker="^", markersize=3, color=PALETTE["EWC"], linewidth=1.3, linestyle="--")
    ax.axvline(REPLAY_CAP_M, color=SUBTEXT_COLOR, linestyle=":", linewidth=0.8); style_axes(ax)
    ax.set_xlabel("Replay cap M", fontsize=7); ax.set_ylabel("ACC", fontsize=7, color=PALETTE["GMR-GAN"])
    ax2e.set_ylabel("BWT", fontsize=7, color=PALETTE["EWC"]); ax2e.grid(False)
    ax.tick_params(labelsize=6); ax2e.tick_params(labelsize=6)
    panel_letter(ax, "E", "Hyperparameter sensitivity"); legend_above(ax, ncol=2, fontsize=5.6, handles=[l1, l2], labels=["ACC (left)", "BWT (right)"])
    ax = axes[1, 2]
    sm = ["ER (raw buffer)", "GMR-VAE", "GMR-GAN", "GMR-Diffusion"]; pl = ["ER", "GMR-VAE", "GMR-GAN", "GMR-Diffusion"]
    for m, pm in zip(sm, pl):
        x_ = table4[table4["Method"] == m]["Disk_MB"].iloc[0]; y_ = float(table2[table2["Method"] == pm]["ACC_mean"].iloc[0])
        ax.scatter([x_], [y_], color=PALETTE.get(pm, SUBTEXT_COLOR), s=40, zorder=5)
        ax.annotate(pm, (x_, y_), fontsize=5.2, xytext=(3, 3), textcoords="offset points", color=SUBTEXT_COLOR)
    style_axes(ax); ax.set_xscale("log"); ax.set_xlabel("Disk footprint (MB, log scale)", fontsize=6.8)
    ax.set_ylabel("ACC", fontsize=7.5); panel_letter(ax, "F", "Storage vs. accuracy")
    save_figure(fig, "figure5_supplementary_dashboard", "Figure 5. Supplementary results.")

    # ---- Figure 6
    fig, axes = plt.subplots(2, 3, figsize=(7.2, 4.6), constrained_layout=True)
    for col, (base, zt) in enumerate(ZT_PAIRS):
        ax = axes[0, col]
        for mn, st in [(base, "-"), (zt, "--")]:
            ys = [table13[(table13["Method"] == mn) & (table13["poison_rate"] == p)]["ACC_mean"].iloc[0] for p in POISON_RATES]
            ax.plot(POISON_RATES, ys, marker="o", markersize=3, linewidth=1.3, linestyle=st, color=PALETTE.get(mn, SUBTEXT_COLOR), label=mn)
        style_axes(ax); ax.set_xlabel("Poison rate", fontsize=6.5)
        if col == 0: ax.set_ylabel("ACC under attack", fontsize=7)
        panel_letter(ax, chr(65 + col), f"{base} family"); legend_above(ax, ncol=1, fontsize=5.2)
        ax = axes[1, col]
        zr = table13[table13["Method"] == zt].sort_values("poison_rate")
        ax.bar([str(p) for p in zr["poison_rate"]], zr["poisoned_sample_rejection_rate"], color=PALETTE.get(zt, SUBTEXT_COLOR), width=0.6)
        style_axes(ax); ax.set_xlabel("Poison rate", fontsize=6.5)
        if col == 0: ax.set_ylabel("Poisoned-sample\nrejection rate", fontsize=6.5)
        panel_letter(ax, chr(68 + col), f"{zt} catch rate")
    save_figure(fig, "figure6_zero_trust_robustness",
                "Figure 6. Zero-Trust Replay adversarial robustness under a simulated compromised generator "
                "(top: ACC vs poison rate, base solid vs +ZT dashed; bottom: poisoned-sample rejection rate).")

    # ---- Figure 7
    fig, axes = plt.subplots(1, 2, figsize=(6.6, 2.9), constrained_layout=True)
    ax = axes[0]; x = np.arange(len(table14)); w = 0.35
    ax.bar(x - w / 2, table14["ACC_base"], width=w, color=PALETTE["control"], label="Base")
    ax.bar(x + w / 2, table14["ACC_plus_ZT"], width=w, color=PALETTE["GMR-GAN-ZT"], label="+ZT")
    for xi, (_, row) in zip(x, table14.iterrows()):
        sg = (not math.isnan(row["p_value_wilcoxon"])) and row["p_value_wilcoxon"] < 0.05
        ax.text(xi, max(row["ACC_base"], row["ACC_plus_ZT"]) + 0.01, "*" if sg else "n.s.", ha="center", fontsize=6, color=TEXT_COLOR)
    ax.set_xticks(x); ax.set_xticklabels(table14["Base_method"], fontsize=6.5); style_axes(ax)
    ax.set_ylabel("ACC", fontsize=7.5); panel_letter(ax, "A", "Clean-utility cost of the ZT defense"); legend_above(ax, ncol=2, fontsize=6)
    ax = axes[1]
    ax.bar(x, table14["clean_utility_cost_of_defense"], color=PALETTE["GMR-GAN-ZT"], width=0.5)
    ax.axhline(0, color=SUBTEXT_COLOR, linewidth=0.8, linestyle="--")
    ax.set_xticks(x); ax.set_xticklabels(table14["Base_method"], fontsize=6.5); style_axes(ax)
    ax.set_ylabel("ACC(base) - ACC(+ZT)", fontsize=7); panel_letter(ax, "B", "Positive = ZT costs accuracy")
    save_figure(fig, "figure7_zero_trust_clean_utility_ablation",
                "Figure 7. Cost of the Zero-Trust defense in the clean setting (Wilcoxon stars from Table 14).")
    checkpoint_save(_STAGE_ID, {"figures_done": True})

# ==============================================================================
# FINAL: package results
# ==============================================================================
print("\n" + "=" * 78); print("Packaging results/ into a zip"); print("=" * 78)
shutil.make_archive(os.path.join(BASE_DIR, "dp_gmr_results"), "zip", RESULTS_DIR)
print("Saved dp_gmr_results.zip (tables/, figures/, raw/, compute_environment.json)")
if not checkpoint_done("11_complete"):
    checkpoint_save("11_complete", {"complete": True})
print("[checkpoint] pipeline complete")
log_memory("end of pipeline")